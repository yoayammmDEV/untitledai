package com.example.ui.screens.vault

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.datastore.UserSettings
import com.example.data.local.entity.AiProviderProfileEntity
import com.example.data.local.entity.CharacterEntity
import com.example.data.local.entity.ChatEntity
import com.example.data.local.entity.StoryEntity
import com.example.data.local.entity.UserPersonaEntity
import com.example.data.repository.StoreBotItem
import com.example.ui.components.AppAsyncImage
import com.example.ui.components.AvatarImage
import com.example.ui.components.FontPickerDialog
import com.example.ui.screens.characters.ChatSelectionDialog
import com.example.ui.viewmodels.MainViewModel
import com.example.ui.viewmodels.MainViewModel.StoreUiState
import kotlinx.coroutines.launch
import org.json.JSONArray

data class VaultBannerItem(
    val title: String,
    val subtitle: String,
    val buttonText: String,
    val icon: ImageVector,
    val badge: String,
    val gradientColors: List<Color>,
    val onClick: () -> Unit
)

data class QuickActionItem(
    val title: String,
    val icon: ImageVector,
    val containerColor: Color,
    val iconTint: Color,
    val onClick: () -> Unit
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultHubScreen(
    characters: List<CharacterEntity>,
    providers: List<AiProviderProfileEntity>,
    stories: List<StoryEntity>,
    chats: List<ChatEntity>,
    activePersona: UserPersonaEntity?,
    userSettings: UserSettings,
    storeState: StoreUiState,
    onRefreshStore: () -> Unit,
    onDownloadStoreBot: (StoreBotItem, (CharacterEntity) -> Unit, (String) -> Unit) -> Unit,
    onUpdateSettings: (UserSettings) -> Unit,
    onCharacterClick: (Long) -> Unit,
    onSelectChat: (Long) -> Unit,
    onCreateNewChatForCharacter: (Long, String, (Long) -> Unit) -> Unit = { _, _, _ -> },
    onTogglePinChat: (Long, Boolean) -> Unit = { _, _ -> },
    onToggleArchiveChat: (Long, Boolean) -> Unit = { _, _ -> },
    onRenameChat: (Long, String) -> Unit = { _, _ -> },
    onDeleteChat: (Long) -> Unit = {},
    onEditCharacter: (Long) -> Unit,
    onCreateCharacter: () -> Unit,
    onImportCharacterJson: (String) -> Unit,
    onTogglePinCharacter: (Long, Boolean) -> Unit,
    onToggleArchiveCharacter: (Long, Boolean) -> Unit,
    onDeleteCharacter: (CharacterEntity) -> Unit,
    onOpenProviders: () -> Unit,
    onOpenPersonas: () -> Unit,
    onOpenStore: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenBackup: () -> Unit,
    onSwitchToClassic: () -> Unit,
    selectedTab: Int? = null,
    fixedTab: Int? = null,
    onTabChange: ((Int) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    val initialTab = remember(userSettings.vaultHubStartTab) {
        if (userSettings.vaultHubStartTab == "chats") 1 else 0
    }
    var internalVaultTab by remember(initialTab) { mutableIntStateOf(initialTab) }
    val currentVaultTab = fixedTab ?: selectedTab ?: internalVaultTab
    val onVaultTabSelect: (Int) -> Unit = { newTab ->
        internalVaultTab = newTab
        onTabChange?.invoke(newTab)
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedTagFilter by remember { mutableStateOf<String?>(null) }
    var inspectBot by remember { mutableStateOf<StoreBotItem?>(null) }
    var downloadingBotName by remember { mutableStateOf<String?>(null) }
    var showFontDialog by remember { mutableStateOf(false) }
    var showFramesVaultDialog by remember { mutableStateOf(false) }
    var selectedCharacterForChats by remember { mutableStateOf<CharacterEntity?>(null) }

    val importFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val json = stream.bufferedReader().use { it.readText() }
                    onImportCharacterJson(json)
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Ошибка импорта: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    if (showFontDialog) {
        FontPickerDialog(
            currentChoice = userSettings.fontFamilyChoice,
            customFontName = userSettings.customFontName,
            glassmorphismEnabled = userSettings.glassmorphismEnabled,
            wallpaperTone = userSettings.wallpaperTone,
            onSelectChoice = { choice ->
                onUpdateSettings(userSettings.copy(fontFamilyChoice = choice))
            },
            onCustomFontImported = { path, name ->
                onUpdateSettings(
                    userSettings.copy(
                        fontFamilyChoice = "custom",
                        customFontPath = path,
                        customFontName = name
                    )
                )
                Toast.makeText(context, "Шрифт «$name» успешно применён!", Toast.LENGTH_SHORT).show()
            },
            onToggleGlassmorphism = { enabled ->
                onUpdateSettings(userSettings.copy(glassmorphismEnabled = enabled))
            },
            onSelectWallpaperTone = { tone ->
                onUpdateSettings(userSettings.copy(wallpaperTone = tone))
            },
            onDismiss = { showFontDialog = false }
        )
    }

    if (showFramesVaultDialog) {
        com.example.ui.components.UserFrameRepositoryDialog(
            userAvatarUri = characters.firstOrNull()?.avatarUri ?: "drawable://avatar_alice",
            currentSelectedFrameUri = userSettings.userActiveFrameUri,
            rawFramesJson = userSettings.userFramesJson,
            onDismiss = { showFramesVaultDialog = false },
            onSelectFrame = { selectedUri ->
                onUpdateSettings(userSettings.copy(userActiveFrameUri = selectedUri))
            },
            onSaveFramesJson = { updatedJson ->
                onUpdateSettings(userSettings.copy(userFramesJson = updatedJson))
            }
        )
    }

    // Hero banners
    val banners = remember {
        listOf(
            VaultBannerItem(
                title = "Конструктор Персонажей",
                subtitle = "Создайте уникального бота с характером, прописанным лором, тоном и баннером",
                buttonText = "Создать бота",
                icon = Icons.Default.Add,
                badge = "СТУДИЯ",
                gradientColors = listOf(Color(0xFF6B21A8), Color(0xFF3B0764)),
                onClick = onCreateCharacter
            ),
            VaultBannerItem(
                title = "Cerebras & Grok API",
                subtitle = "Модели gpt-oss-120b, Llama 3.3 70B, Grok и OpenRouter с диагностикой запросов",
                buttonText = "Настроить API",
                icon = Icons.Default.Bolt,
                badge = "НЕЙРОСЕТИ",
                gradientColors = listOf(Color(0xFFB45309), Color(0xFF78350F)),
                onClick = onOpenProviders
            ),
            VaultBannerItem(
                title = "Пользовательские Персоны",
                subtitle = "Настройте ваш собственный профиль и маску для реалистичного отыгрыша в диалогах",
                buttonText = "Мои персоны",
                icon = Icons.Default.Person,
                badge = "ОТЫГРЫШ",
                gradientColors = listOf(Color(0xFF0F766E), Color(0xFF134E4A)),
                onClick = onOpenPersonas
            )
        )
    }

    // Quick action buttons
    val quickActions = remember {
        listOf(
            QuickActionItem("Создать", Icons.Default.AddCircle, Color(0xFF8B5CF6).copy(alpha = 0.2f), Color(0xFFC4B5FD), onCreateCharacter),
            QuickActionItem("Рамки", Icons.Default.FilterFrames, Color(0xFFF97316).copy(alpha = 0.2f), Color(0xFFFED7AA)) { showFramesVaultDialog = true },
            QuickActionItem("Импорт", Icons.Default.FileUpload, Color(0xFF3B82F6).copy(alpha = 0.2f), Color(0xFF93C5FD)) { importFileLauncher.launch("*/*") },
            QuickActionItem("Провайдеры", Icons.Default.Bolt, Color(0xFFF59E0B).copy(alpha = 0.2f), Color(0xFFFDE68A), onOpenProviders),
            QuickActionItem("Персоны", Icons.Default.Face, Color(0xFF10B981).copy(alpha = 0.2f), Color(0xFFA7F3D0), onOpenPersonas),
            QuickActionItem("Шрифты", Icons.Default.TextFields, Color(0xFF6366F1).copy(alpha = 0.2f), Color(0xFFA5B4FC)) { showFontDialog = true },
            QuickActionItem("Стиль", Icons.Default.Palette, Color(0xFFEC4899).copy(alpha = 0.2f), Color(0xFFFBCFE8), onOpenSettings),
            QuickActionItem("Бэкап", Icons.Default.Save, Color(0xFF14B8A6).copy(alpha = 0.2f), Color(0xFF99F6E4), onOpenBackup)
        )
    }

    // O(1) lookup maps to eliminate O(N*M) list scans during tab switches on low-end devices
    val charactersByLowerName = remember(characters) {
        characters.associateBy { it.name.trim().lowercase() }
    }
    val chatsByCharacterId = remember(chats) {
        chats.groupBy { it.characterId }
    }

    // Top-level remember state for online catalog (only computed when on Tab 0)
    val allBots = remember(storeState, currentVaultTab) {
        if (currentVaultTab == 0 && storeState is StoreUiState.Success) storeState.catalog.characters else emptyList()
    }

    val uniqueTags = remember(allBots) {
        if (allBots.isEmpty()) emptyList()
        else {
            val tagsSet = LinkedHashSet<String>()
            allBots.forEach { tagsSet.addAll(it.tags) }
            tagsSet.sorted()
        }
    }

    val filteredBots = remember(allBots, searchQuery, selectedTagFilter) {
        if (allBots.isEmpty()) emptyList()
        else {
            val q = searchQuery.trim()
            allBots.filter { bot ->
                val matchesQuery = q.isBlank() ||
                        bot.name.contains(q, ignoreCase = true) ||
                        bot.shortDescription.contains(q, ignoreCase = true) ||
                        bot.author.contains(q, ignoreCase = true) ||
                        bot.tags.any { it.contains(q, ignoreCase = true) }

                val matchesTag = selectedTagFilter == null || bot.tags.contains(selectedTagFilter)
                matchesQuery && matchesTag
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.Storage,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Новый Untitled",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "Интеллектуальный хаб персонажей и диалогов",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onRefreshStore) {
                        Icon(Icons.Default.Refresh, contentDescription = "Обновить каталог", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { showFontDialog = true }) {
                        Icon(Icons.Default.TextFields, contentDescription = "Шрифты и стиль", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Настройки")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Vault Mode Navigation Tabs: 0: "Общее" (box.json), 1: "Чаты" (Диалоги)
            PrimaryTabRow(
                selectedTabIndex = currentVaultTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Tab(
                    selected = currentVaultTab == 0,
                    onClick = { onVaultTabSelect(0) },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Общее (Хранилище)", fontWeight = FontWeight.Bold)
                        }
                    }
                )
                Tab(
                    selected = currentVaultTab == 1,
                    onClick = { onVaultTabSelect(1) },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Чаты (${chats.size})", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }

            when (currentVaultTab) {
                0 -> {
                    // MAIN VAULT TAB: Banners, Quick Actions, and GitHub Box.json Online Showcase
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // 1. Hero Banners Pager
                        item {
                            val pagerState = rememberPagerState(pageCount = { banners.size })
                            Column {
                                HorizontalPager(
                                    state = pagerState,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(160.dp)
                                ) { page ->
                                    val item = banners[page]
                                    VaultHeroBannerCard(item = item)
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    repeat(banners.size) { idx ->
                                        val isSelected = pagerState.currentPage == idx
                                        Box(
                                            modifier = Modifier
                                                .padding(horizontal = 3.dp)
                                                .size(if (isSelected) 8.dp else 6.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                                )
                                        )
                                    }
                                }
                            }
                        }

                        // 2. Quick Actions Grid
                        item {
                            Text(
                                text = "Быстрые действия",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                quickActions.take(4).forEach { action ->
                                    QuickActionButtonItem(action = action)
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                quickActions.drop(4).take(4).forEach { action ->
                                    QuickActionButtonItem(action = action)
                                }
                            }
                        }

                        // 3. GitHub Box.json Online Showcase Header
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Персонажи в Хранилище",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Каталог из GitHub репозитория (box-of-untitledAI/box.json)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                IconButton(onClick = onRefreshStore) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Обновить",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("Поиск в Хранилище по имени, описанию или тегу...") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { searchQuery = "" }) {
                                            Icon(Icons.Default.Close, contentDescription = "Очистить")
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        // 4. Online Catalog Content
                        when (storeState) {
                            is StoreUiState.Idle, is StoreUiState.Loading -> {
                                item {
                                    Surface(
                                        shape = RoundedCornerShape(16.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(24.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                                            Spacer(modifier = Modifier.height(12.dp))
                                            Text("Загрузка персонажей из box.json...", fontWeight = FontWeight.Bold)
                                            Text("Подключение к GitHub репозиторию bad-kn1fe-cmd/box-of-untitledAI", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }

                            is StoreUiState.Error, is StoreUiState.Offline -> {
                                val errMessage = if (storeState is StoreUiState.Offline) storeState.message else (storeState as StoreUiState.Error).message
                                item {
                                    Surface(
                                        shape = RoundedCornerShape(16.dp),
                                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(16.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Icon(Icons.Default.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(36.dp))
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text("Не удалось загрузить Хранилище", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(errMessage, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Spacer(modifier = Modifier.height(12.dp))
                                            Button(onClick = onRefreshStore, shape = RoundedCornerShape(8.dp)) {
                                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Повторить попытку")
                                            }
                                        }
                                    }
                                }
                            }

                            is StoreUiState.Success -> {
                                item {
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        item {
                                            FilterChip(
                                                selected = selectedTagFilter == null,
                                                onClick = { selectedTagFilter = null },
                                                label = { Text("Все (${allBots.size})", fontSize = 11.5.sp) },
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                        }
                                        items(uniqueTags) { tag ->
                                            FilterChip(
                                                selected = selectedTagFilter == tag,
                                                onClick = { selectedTagFilter = if (selectedTagFilter == tag) null else tag },
                                                label = { Text(tag, fontSize = 11.5.sp) },
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                        }
                                    }
                                }

                                if (filteredBots.isEmpty()) {
                                    item {
                                        Surface(
                                            shape = RoundedCornerShape(16.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                            modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp)
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(24.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                Icon(Icons.Default.PersonSearch, contentDescription = null, modifier = Modifier.size(40.dp))
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text("Боты не найдены", fontWeight = FontWeight.Bold)
                                                Text("Попробуйте изменить запрос поиска", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                } else {
                                    items(filteredBots, key = { "${it.name}_${it.author}" }) { bot ->
                                        val isImporting = downloadingBotName == bot.name
                                        val existingChar = charactersByLowerName[bot.name.trim().lowercase()]
                                        val botChats = if (existingChar != null) {
                                            chatsByCharacterId[existingChar.id].orEmpty()
                                        } else {
                                            emptyList()
                                        }

                                        StoreBotCardItem(
                                            bot = bot,
                                            isAlreadyImported = existingChar != null,
                                            chatsCount = botChats.size,
                                            isDownloading = isImporting,
                                            onInspect = { inspectBot = bot },
                                            onEdit = if (existingChar != null) { { onEditCharacter(existingChar.id) } } else null,
                                            onStartOrDownload = {
                                                if (existingChar != null) {
                                                    if (botChats.size > 1) {
                                                        selectedCharacterForChats = existingChar
                                                    } else {
                                                        onCharacterClick(existingChar.id)
                                                    }
                                                } else {
                                                    downloadingBotName = bot.name
                                                    onDownloadStoreBot(bot, { newChar ->
                                                        downloadingBotName = null
                                                        Toast.makeText(context, "Бот «${newChar.name}» успешно импортирован!", Toast.LENGTH_SHORT).show()
                                                        onCharacterClick(newChar.id)
                                                    }, { err ->
                                                        downloadingBotName = null
                                                        Toast.makeText(context, "Ошибка импорта: $err", Toast.LENGTH_LONG).show()
                                                    })
                                                }
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // DEDICATED DIALOGS TAB (Grouped by Character)
                    VaultChatsTab(
                        chats = chats,
                        characters = characters,
                        searchQuery = searchQuery,
                        userSettings = userSettings,
                        onSearchChange = { searchQuery = it },
                        onSelectChat = onSelectChat,
                        onOpenChatChooser = { char -> selectedCharacterForChats = char },
                        onCreateCharacter = onCreateCharacter,
                        onEditCharacter = onEditCharacter,
                        onCharacterClick = onCharacterClick
                    )
                }
            }
        }
    }

    // Bot Detailed Profile Modal
    if (inspectBot != null) {
        val bot = inspectBot!!
        val existingChar = characters.find { it.name.trim().equals(bot.name.trim(), ignoreCase = true) }
        val botChats = remember(chats, existingChar?.id) {
            if (existingChar != null) chats.filter { it.characterId == existingChar.id } else emptyList()
        }

        VaultBotInspectDialog(
            bot = bot,
            isAlreadyImported = existingChar != null,
            onDismiss = { inspectBot = null },
            onEditCharacter = { existingChar?.let { onEditCharacter(it.id) } },
            onImportAndChat = {
                inspectBot = null
                if (existingChar != null) {
                    if (botChats.size > 1) {
                        selectedCharacterForChats = existingChar
                    } else {
                        onCharacterClick(existingChar.id)
                    }
                } else {
                    downloadingBotName = bot.name
                    onDownloadStoreBot(bot, { newChar ->
                        downloadingBotName = null
                        Toast.makeText(context, "Бот «${newChar.name}» импортирован!", Toast.LENGTH_SHORT).show()
                        onCharacterClick(newChar.id)
                    }, { err ->
                        downloadingBotName = null
                        Toast.makeText(context, "Ошибка: $err", Toast.LENGTH_LONG).show()
                    })
                }
            }
        )
    }

    // Multi-Chat Choice Dialog for a Character
    if (selectedCharacterForChats != null) {
        val targetCharacter = selectedCharacterForChats!!
        val characterChats = remember(chats, targetCharacter.id) {
            chats.filter { it.characterId == targetCharacter.id }
        }

        ChatSelectionDialog(
            character = targetCharacter,
            chats = characterChats,
            onDismiss = { selectedCharacterForChats = null },
            onSelectChat = { chatId ->
                selectedCharacterForChats = null
                onSelectChat(chatId)
            },
            onCreateNewChat = { title ->
                onCreateNewChatForCharacter(targetCharacter.id, title) { newId ->
                    selectedCharacterForChats = null
                    onSelectChat(newId)
                }
            },
            onTogglePinChat = onTogglePinChat,
            onToggleArchiveChat = onToggleArchiveChat,
            onRenameChat = onRenameChat,
            onDeleteChat = onDeleteChat,
            onEditCharacter = {
                onEditCharacter(targetCharacter.id)
            }
        )
    }
}

@Composable
fun StoreBotCardItem(
    bot: StoreBotItem,
    isAlreadyImported: Boolean,
    chatsCount: Int = 0,
    isDownloading: Boolean,
    onInspect: () -> Unit,
    onStartOrDownload: () -> Unit,
    onEdit: (() -> Unit)? = null
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable { onInspect() }
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Banner Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
            ) {
                if (bot.bannerUri.isNotBlank()) {
                    AppAsyncImage(
                        model = bot.bannerUri,
                        contentDescription = "Баннер ${bot.name}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f))
                                )
                            )
                    )
                } else if (bot.avatarUri.isNotBlank()) {
                    AppAsyncImage(
                        model = bot.avatarUri,
                        contentDescription = "Фон ${bot.name}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Black.copy(alpha = 0.35f), Color.Black.copy(alpha = 0.75f))
                                )
                            )
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                                        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f)
                                    )
                                )
                            )
                    )
                }

                // Top badges
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(shape = RoundedCornerShape(6.dp), color = Color.Black.copy(alpha = 0.6f)) {
                        Text(
                            text = "by ${bot.author.ifBlank { "UntitledAI" }}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (chatsCount > 1) {
                            Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.primary) {
                                Text(
                                    text = "💬 $chatsCount ветки",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Body
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AvatarImage(
                    uri = bot.avatarUri,
                    contentDescription = bot.name,
                    size = 56.dp,
                    frameUri = bot.avatarFrameUri
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = bot.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (bot.shortDescription.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = bot.shortDescription,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                if (isAlreadyImported && onEdit != null) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Редактировать",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                }

                Button(
                    onClick = onStartOrDownload,
                    enabled = !isDownloading,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    if (isDownloading) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                    } else {
                        Icon(
                            imageVector = if (isAlreadyImported) Icons.AutoMirrored.Filled.Chat else Icons.Default.Download,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isAlreadyImported) (if (chatsCount > 1) "Выбор" else "Чат") else "Забрать", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun VaultHeroBannerCard(item: VaultBannerItem) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(155.dp)
            .padding(horizontal = 4.dp),
        shadowElevation = 3.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(item.gradientColors))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.72f),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color.White.copy(alpha = 0.22f)
                    ) {
                        Text(
                            text = item.badge,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = item.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 11.5.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 15.sp
                    )
                }

                Button(
                    onClick = item.onClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color(0xFF1E1B4B)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text(item.buttonText, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(14.dp))
                }
            }

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.12f))
                    .align(Alignment.CenterEnd),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.size(44.dp)
                )
            }
        }
    }
}

@Composable
fun QuickActionButtonItem(action: QuickActionItem) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(76.dp)
            .clickable { action.onClick() }
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = action.containerColor,
            modifier = Modifier.size(52.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = action.icon,
                    contentDescription = action.title,
                    tint = action.iconTint,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = action.title,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun VaultChatsTab(
    chats: List<ChatEntity>,
    characters: List<CharacterEntity>,
    searchQuery: String,
    userSettings: UserSettings,
    onSearchChange: (String) -> Unit,
    onSelectChat: (Long) -> Unit,
    onOpenChatChooser: (CharacterEntity) -> Unit,
    onCreateCharacter: () -> Unit,
    onEditCharacter: (Long) -> Unit = {},
    onCharacterClick: (Long) -> Unit = {}
) {
    var selectedCategory by remember { mutableStateOf("all") } // "all", "pinned", "assistants", "archived"

    val chatsByCharId = remember(chats) {
        chats.groupBy { it.characterId }.mapValues { (_, list) -> list.sortedByDescending { it.updatedAt } }
    }

    // Group chats by CharacterEntity using O(1) map lookup
    val groupedCharacterChats = remember(chatsByCharId, characters, searchQuery, selectedCategory) {
        val q = searchQuery.trim()
        characters.mapNotNull { char ->
            val botChats = chatsByCharId[char.id].orEmpty()
            val matchesQuery = q.isBlank() ||
                    char.name.contains(q, ignoreCase = true) ||
                    botChats.any { it.title.contains(q, ignoreCase = true) }

            val matchesCategory = when (selectedCategory) {
                "pinned" -> char.isPinned || botChats.any { it.isPinned }
                "assistants" -> char.isAssistant
                "archived" -> char.isArchived || (botChats.isNotEmpty() && botChats.all { it.isArchived })
                else -> !char.isArchived && !char.isHidden
            }
            if (matchesQuery && matchesCategory) Pair(char, botChats) else null
        }.sortedByDescending { (char, botChats) ->
            botChats.firstOrNull()?.updatedAt ?: char.createdAt
        }
    }

    val categories = remember(chatsByCharId, characters) {
        listOf(
            "all" to "Все (${characters.size})",
            "pinned" to "📌 Закрепленные (${characters.count { char ->
                val cChats = chatsByCharId[char.id].orEmpty()
                char.isPinned || cChats.any { it.isPinned }
            }})",
            "assistants" to "⚡ Ассистенты (${characters.count { it.isAssistant }})",
            "archived" to "📦 Архив (${characters.count { char ->
                val cChats = chatsByCharId[char.id].orEmpty()
                char.isArchived || (cChats.isNotEmpty() && cChats.all { it.isArchived })
            }})"
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            placeholder = { Text("Поиск диалога или персонажа...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(Icons.Default.Close, contentDescription = "Очистить")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Category Filter Chips in Dialogs Tab
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(categories) { (id, label) ->
                FilterChip(
                    selected = selectedCategory == id,
                    onClick = { selectedCategory = id },
                    label = { Text(label, fontSize = 11.5.sp) },
                    shape = RoundedCornerShape(8.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (groupedCharacterChats.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Нет персонажей в данной категории", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("Создайте нового персонажа или заберите из Хранилища", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(groupedCharacterChats, key = { (char, _) -> char.id }) { (char, botChats) ->
                    val latestChat = botChats.firstOrNull()
                    val chatCount = botChats.size

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(
                            1.dp,
                            if (latestChat?.isPinned == true || char.isPinned) MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)
                            else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
                        ),
                        shadowElevation = 2.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .clickable {
                                if (chatCount > 1) {
                                    onOpenChatChooser(char)
                                } else if (latestChat != null) {
                                    onSelectChat(latestChat.id)
                                } else {
                                    onCharacterClick(char.id)
                                }
                            }
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            // Character Banner on top of Chat Card
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(80.dp)
                            ) {
                                if (char.bannerUri.isNotBlank()) {
                                    AppAsyncImage(
                                        model = char.bannerUri,
                                        contentDescription = "Баннер ${char.name}",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(
                                                Brush.verticalGradient(
                                                    listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f))
                                                )
                                            )
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(
                                                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                                        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                                                    )
                                                )
                                            )
                                    )
                                }

                                // Top badges overlay
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = Color.Black.copy(alpha = 0.55f)
                                    ) {
                                        val relText = if (latestChat != null) {
                                            if (latestChat.customRelationship.isNotBlank()) {
                                                latestChat.customRelationship
                                            } else {
                                                when (latestChat.relationshipType) {
                                                    "friends" -> "🤝 Друзья"
                                                    "close_friends" -> "💖 Близкие друзья"
                                                    "romantic" -> "❤️ Романтика"
                                                    "acquaintances" -> "👋 Знакомые"
                                                    else -> "🌱 Знакомство"
                                                }
                                            }
                                        } else {
                                            if (char.customRelationship.isNotBlank()) {
                                                char.customRelationship
                                            } else {
                                                when (char.startingRelationship) {
                                                    "friends" -> "🤝 Друзья"
                                                    "close_friends" -> "💖 Близкие друзья"
                                                    "romantic" -> "❤️ Романтика"
                                                    "acquaintances" -> "👋 Знакомые"
                                                    else -> "🌱 Знакомство"
                                                }
                                            }
                                        }
                                        Text(
                                            text = relText,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        if (chatCount > 1) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.primary
                                            ) {
                                                Text(
                                                    text = "💬 $chatCount ветки",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onPrimary,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }

                                        if (latestChat?.isPinned == true || char.isPinned) {
                                            Surface(
                                                shape = CircleShape,
                                                color = MaterialTheme.colorScheme.primary
                                            ) {
                                                Icon(
                                                    Icons.Default.PushPin,
                                                    contentDescription = "Закреплен",
                                                    tint = MaterialTheme.colorScheme.onPrimary,
                                                    modifier = Modifier.padding(4.dp).size(12.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Card Content below Banner
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AvatarImage(
                                    uri = char.avatarUri,
                                    contentDescription = char.name,
                                    size = 48.dp,
                                    frameUri = char.avatarFrameUri
                                )

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = char.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )

                                        if (char.author.isNotBlank()) {
                                            Text(
                                                text = "by ${char.author}",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (chatCount > 1 && latestChat != null) "Последний: ${latestChat.title}" else if (latestChat != null) latestChat.title else char.greetingMessage.ifBlank { "Нажмите, чтобы начать диалог" },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )

                                    val tagsList = remember(char.tags) {
                                        try {
                                            val arr = JSONArray(char.tags)
                                            val list = mutableListOf<String>()
                                            for (i in 0 until arr.length()) {
                                                val t = arr.optString(i, "").trim()
                                                if (t.isNotBlank()) list.add(t)
                                            }
                                            list
                                        } catch (_: Exception) {
                                            emptyList<String>()
                                        }
                                    }

                                    if (tagsList.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .horizontalScroll(rememberScrollState()),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            tagsList.forEach { tag ->
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                                                    border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                                                ) {
                                                    Text(
                                                        text = "#$tag",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Medium,
                                                        color = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                IconButton(
                                    onClick = { onEditCharacter(char.id) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Редактировать персонажа",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                if (chatCount > 1) {
                                    OutlinedButton(
                                        onClick = { onOpenChatChooser(char) },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text("Выбрать", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                } else if (chatCount == 1) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = "Открыть",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                } else {
                                    OutlinedButton(
                                        onClick = { onCharacterClick(char.id) },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text("Начать", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VaultBotInspectDialog(
    bot: StoreBotItem,
    isAlreadyImported: Boolean,
    onDismiss: () -> Unit,
    onImportAndChat: () -> Unit,
    onEditCharacter: (() -> Unit)? = null
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.85f)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header Banner
                Box(modifier = Modifier.fillMaxWidth().height(140.dp)) {
                    if (bot.bannerUri.isNotBlank()) {
                        AppAsyncImage(
                            model = bot.bannerUri,
                            contentDescription = bot.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(
                            modifier = Modifier.fillMaxSize().background(
                                Brush.linearGradient(
                                    listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary)
                                )
                            )
                        )
                    }
                    Box(
                        modifier = Modifier.fillMaxSize().background(
                            Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)))
                        )
                    )

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Закрыть", tint = Color.White)
                    }

                    Row(
                        modifier = Modifier.align(Alignment.BottomStart).padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AvatarImage(uri = bot.avatarUri, contentDescription = bot.name, size = 56.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(bot.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Автор: ${bot.author.ifBlank { "UntitledAI" }}", fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f))
                        }
                    }
                }

                // Scrollable details
                Column(
                    modifier = Modifier.weight(1f).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (bot.shortDescription.isNotBlank()) {
                        Text("Описание", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text(bot.shortDescription, style = MaterialTheme.typography.bodySmall)
                    }

                    if (bot.personality.isNotBlank()) {
                        Text("Характер и лор", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text(bot.personality, style = MaterialTheme.typography.bodySmall, maxLines = 6, overflow = TextOverflow.Ellipsis)
                    }

                    if (bot.greetingMessage.isNotBlank()) {
                        Text("Приветствие", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)) {
                            Text(bot.greetingMessage, modifier = Modifier.padding(10.dp), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                HorizontalDivider()

                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Закрыть")
                    }
                    if (isAlreadyImported && onEditCharacter != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedButton(
                            onClick = {
                                onDismiss()
                                onEditCharacter()
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Изменить")
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(onClick = onImportAndChat, shape = RoundedCornerShape(10.dp)) {
                        Icon(if (isAlreadyImported) Icons.AutoMirrored.Filled.Chat else Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isAlreadyImported) "Перейти в чат" else "Забрать и начать чат")
                    }
                }
            }
        }
    }
}
