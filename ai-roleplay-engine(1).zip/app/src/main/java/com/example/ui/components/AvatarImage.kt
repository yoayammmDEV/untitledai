package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.util.ImageStorageHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun AvatarImage(
    uri: String,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    frameUri: String = ""
) {
    val context = LocalContext.current
    val cleanUri = uri.trim()
    val cleanFrameUri = frameUri.trim()
    val hasFrame = cleanFrameUri.isNotBlank()
    val targetDim = (size.value * 3).toInt().coerceIn(128, 512)

    var decodedAvatar by remember(cleanUri) {
        mutableStateOf(ImageStorageHelper.peekCachedBitmap(cleanUri, targetDim))
    }

    LaunchedEffect(cleanUri) {
        if (decodedAvatar == null && cleanUri.isNotBlank() && !cleanUri.startsWith("drawable://") && !cleanUri.startsWith("http")) {
            val loaded = withContext(Dispatchers.IO) {
                ImageStorageHelper.loadCachedBitmap(context, cleanUri, targetDim)
            }
            if (loaded != null) {
                decodedAvatar = loaded
            }
        }
    }

    var decodedFrame by remember(cleanFrameUri) {
        mutableStateOf(ImageStorageHelper.peekCachedBitmap(cleanFrameUri, targetDim))
    }

    LaunchedEffect(cleanFrameUri) {
        if (decodedFrame == null && cleanFrameUri.isNotBlank() && !cleanFrameUri.startsWith("http")) {
            val loaded = withContext(Dispatchers.IO) {
                ImageStorageHelper.loadCachedBitmap(context, cleanFrameUri, targetDim)
            }
            if (loaded != null) {
                decodedFrame = loaded
            }
        }
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        // Inner Circular Avatar
        Box(
            modifier = Modifier
                .fillMaxSize(if (hasFrame) AVATAR_FRAME_INNER_RATIO else 1f)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            when {
                decodedAvatar != null -> {
                    Image(
                        bitmap = decodedAvatar!!.asImageBitmap(),
                        contentDescription = contentDescription,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                cleanUri == "drawable://app_logo_black" || cleanUri == "drawable://ic_app_logo_black" || cleanUri == "drawable://avatar_app_dark" -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        AppLogo(size = size * 0.9f, shapeRadius = size * 0.45f, isDark = true)
                    }
                }
                cleanUri == "drawable://app_logo_white" || cleanUri == "drawable://ic_app_logo_white" -> {
                    AppLogo(size = size, shapeRadius = size * 0.5f, isDark = false)
                }
                cleanUri == "drawable://ic_app_logo" -> {
                    AppLogo(size = size, shapeRadius = size * 0.5f)
                }
                cleanUri.startsWith("drawable://") -> {
                    val resName = cleanUri.removePrefix("drawable://")
                    val resId = when (resName) {
                        "avatar_alice" -> R.drawable.avatar_alice
                        "avatar_elena" -> R.drawable.avatar_elena
                        "avatar_marcus" -> R.drawable.avatar_marcus
                        "appearance_elena_full" -> R.drawable.appearance_elena_full
                        else -> 0
                    }
                    if (resId != 0) {
                        Image(
                            painter = painterResource(id = resId),
                            contentDescription = contentDescription,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = contentDescription,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(size * 0.6f)
                        )
                    }
                }
                cleanUri.startsWith("http://") || cleanUri.startsWith("https://") -> {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(cleanUri)
                            .crossfade(false)
                            .build(),
                        contentDescription = contentDescription,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                else -> {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = contentDescription,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(size * 0.6f)
                    )
                }
            }
        }

        // Frame Overlay
        if (hasFrame) {
            val isParallax = FrameParallaxController.isEnabled
            val frameModifier = if (isParallax) {
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        translationX = FrameParallaxController.currentTiltX
                        translationY = FrameParallaxController.currentTiltY
                    }
            } else {
                Modifier.fillMaxSize()
            }

            if (decodedFrame != null) {
                Image(
                    bitmap = decodedFrame!!.asImageBitmap(),
                    contentDescription = "Avatar Frame",
                    contentScale = ContentScale.Fit,
                    modifier = frameModifier
                )
            } else if (cleanFrameUri.startsWith("http://") || cleanFrameUri.startsWith("https://")) {
                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data(cleanFrameUri)
                        .crossfade(false)
                        .build(),
                    contentDescription = "Avatar Frame",
                    contentScale = ContentScale.Fit,
                    modifier = frameModifier
                )
            }
        }
    }
}
