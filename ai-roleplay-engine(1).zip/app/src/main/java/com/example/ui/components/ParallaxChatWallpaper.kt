package com.example.ui.components

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.launch

data class WallpaperInfo(
    val id: String,
    val name: String,
    val subtitle: String,
    val isCustom: Boolean = false
)

val WallpaperPresetsList = listOf(
    WallpaperInfo("none", "Без фона", "Чистый цвет темы"),
    WallpaperInfo("pattern_chat_icons", "Диалоги и искры", "Сетка чат-значков и звезд"),
    WallpaperInfo("pattern_stars_constellation", "Звездное небо", "Ночной индиго с созвездиями"),
    WallpaperInfo("pattern_geometric_mesh", "Неон-геометрия", "Темный графит с гексагонами"),
    WallpaperInfo("pattern_aurora_gradient", "Градиент Аврора", "Шелковый изумруд и индиго"),
    WallpaperInfo("custom", "Свой фон", "Импорт из галереи", isCustom = true)
)

@Composable
fun ProceduralWallpaper(
    preset: String,
    modifier: Modifier = Modifier
) {
    when (preset) {
        "pattern_chat_icons" -> ChatIconsPattern(modifier)
        "pattern_stars_constellation" -> StarsConstellationPattern(modifier)
        "pattern_geometric_mesh" -> GeometricMeshPattern(modifier)
        "pattern_aurora_gradient" -> AuroraGradientPattern(modifier)
        else -> {
            Box(
                modifier = modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xFF0C101A),
                                Color(0xFF141926),
                                Color(0xFF0D1018)
                            )
                        )
                    )
            )
        }
    }
}

@Composable
fun ChatIconsPattern(modifier: Modifier = Modifier) {
    val bgBrush = remember {
        Brush.verticalGradient(
            listOf(
                Color(0xFF0B0E17),
                Color(0xFF131828),
                Color(0xFF0E121F)
            )
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(bgBrush)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cellW = 56.dp.toPx()
            val cellH = 56.dp.toPx()
            val cols = (size.width / cellW).toInt() + 2
            val rows = (size.height / cellH).toInt() + 2

            val iconColor1 = Color.White.copy(alpha = 0.07f)
            val iconColor2 = Color(0xFF8BB4F8).copy(alpha = 0.08f)
            val iconColor3 = Color(0xFFD0BCFF).copy(alpha = 0.08f)
            val stroke = Stroke(width = 1.4.dp.toPx())

            for (r in 0 until rows) {
                val rowOffset = if (r % 2 == 1) cellW * 0.5f else 0f
                val y = r * cellH + cellH * 0.5f

                for (c in 0 until cols) {
                    val x = c * cellW + rowOffset
                    val shapeIdx = (r * 3 + c) % 4
                    val color = when (shapeIdx % 3) {
                        0 -> iconColor1
                        1 -> iconColor2
                        else -> iconColor3
                    }

                    when (shapeIdx) {
                        0 -> {
                            // Chat bubble
                            val bw = 16.dp.toPx()
                            val bh = 11.dp.toPx()
                            drawRoundRect(
                                color = color,
                                topLeft = Offset(x - bw / 2, y - bh / 2),
                                size = Size(bw, bh),
                                cornerRadius = CornerRadius(3.5.dp.toPx(), 3.5.dp.toPx()),
                                style = stroke
                            )
                            val tailPath = Path().apply {
                                moveTo(x - bw / 2 + 3.dp.toPx(), y + bh / 2)
                                lineTo(x - bw / 2 - 2.dp.toPx(), y + bh / 2 + 3.5.dp.toPx())
                                lineTo(x - bw / 2 + 7.dp.toPx(), y + bh / 2)
                                close()
                            }
                            drawPath(tailPath, color = color, style = stroke)
                        }
                        1 -> {
                            // Four-point sparkle
                            val rSpark = 7.dp.toPx()
                            val sparkPath = Path().apply {
                                moveTo(x, y - rSpark)
                                quadraticTo(x, y, x + rSpark, y)
                                quadraticTo(x, y, x, y + rSpark)
                                quadraticTo(x, y, x - rSpark, y)
                                quadraticTo(x, y, x, y - rSpark)
                                close()
                            }
                            drawPath(sparkPath, color = color, style = stroke)
                        }
                        2 -> {
                            // Heart icon
                            val hw = 12.dp.toPx()
                            val hh = 11.dp.toPx()
                            val heartPath = Path().apply {
                                moveTo(x, y + hh * 0.45f)
                                cubicTo(x - hw, y - hh * 0.2f, x - hw * 0.5f, y - hh * 0.6f, x, y - hh * 0.2f)
                                cubicTo(x + hw * 0.5f, y - hh * 0.6f, x + hw, y - hh * 0.2f, x, y + hh * 0.45f)
                                close()
                            }
                            drawPath(heartPath, color = color, style = stroke)
                        }
                        3 -> {
                            // 3 dots / ellipsis
                            val dotR = 1.6.dp.toPx()
                            val spacing = 4.5.dp.toPx()
                            drawCircle(color, radius = dotR, center = Offset(x - spacing, y))
                            drawCircle(color, radius = dotR, center = Offset(x, y))
                            drawCircle(color, radius = dotR, center = Offset(x + spacing, y))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StarsConstellationPattern(modifier: Modifier = Modifier) {
    val bgBrush = remember {
        Brush.verticalGradient(
            listOf(
                Color(0xFF080B14),
                Color(0xFF10152B),
                Color(0xFF18112C),
                Color(0xFF0A0D18)
            )
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(bgBrush)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val starColor = Color.White.copy(alpha = 0.18f)
            val dimStar = Color(0xFFC5CAE9).copy(alpha = 0.09f)
            val lineColor = Color(0xFF7986CB).copy(alpha = 0.06f)

            val cols = 6
            val rows = 12
            val cellW = size.width / cols
            val cellH = size.height / rows

            val starPoints = mutableListOf<Offset>()

            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val pseudoRandomX = ((c * 37 + r * 59) % 100) / 100f
                    val pseudoRandomY = ((c * 43 + r * 71) % 100) / 100f
                    val px = c * cellW + pseudoRandomX * cellW
                    val py = r * cellH + pseudoRandomY * cellH
                    starPoints.add(Offset(px, py))

                    val isSpark = (c + r) % 5 == 0
                    if (isSpark) {
                        val s = 6.dp.toPx()
                        drawLine(starColor, Offset(px - s, py), Offset(px + s, py), strokeWidth = 1.2.dp.toPx())
                        drawLine(starColor, Offset(px, py - s), Offset(px, py + s), strokeWidth = 1.2.dp.toPx())
                        drawCircle(Color.White.copy(alpha = 0.25f), radius = 2.dp.toPx(), center = Offset(px, py))
                    } else {
                        val rad = if ((c * 7 + r) % 3 == 0) 2.2.dp.toPx() else 1.4.dp.toPx()
                        drawCircle(dimStar, radius = rad, center = Offset(px, py))
                    }
                }
            }

            // Draw subtle constellation lines between nearby stars
            for (i in 0 until starPoints.size - 1) {
                if (i % 3 == 0 && i + 1 < starPoints.size) {
                    val p1 = starPoints[i]
                    val p2 = starPoints[i + 1]
                    val dist = (p1 - p2).getDistance()
                    if (dist < cellW * 1.6f) {
                        drawLine(lineColor, p1, p2, strokeWidth = 1.dp.toPx())
                    }
                }
            }
        }
    }
}

@Composable
fun GeometricMeshPattern(modifier: Modifier = Modifier) {
    val bgBrush = remember {
        Brush.verticalGradient(
            listOf(
                Color(0xFF090C11),
                Color(0xFF101724),
                Color(0xFF0A0F17)
            )
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(bgBrush)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val step = 28.dp.toPx()
            val cols = (size.width / step).toInt() + 1
            val rows = (size.height / step).toInt() + 1

            val dotColor = Color.White.copy(alpha = 0.05f)
            val accentColor = Color(0xFF64FFDA).copy(alpha = 0.10f)
            val stroke = Stroke(width = 1.2.dp.toPx())

            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val x = c * step
                    val y = r * step

                    if ((c + r) % 6 == 0) {
                        // Small cross '+'
                        val s = 3.5.dp.toPx()
                        drawLine(accentColor, Offset(x - s, y), Offset(x + s, y), strokeWidth = 1.2.dp.toPx())
                        drawLine(accentColor, Offset(x, y - s), Offset(x, y + s), strokeWidth = 1.2.dp.toPx())
                    } else if ((c * 2 + r * 3) % 11 == 0) {
                        // Tiny hexagon
                        val rad = 5.dp.toPx()
                        val hexPath = Path()
                        for (i in 0 until 6) {
                            val angle = (i * 60f * PI / 180f).toFloat()
                            val hx = x + rad * cos(angle)
                            val hy = y + rad * sin(angle)
                            if (i == 0) hexPath.moveTo(hx, hy) else hexPath.lineTo(hx, hy)
                        }
                        hexPath.close()
                        drawPath(hexPath, color = accentColor, style = stroke)
                    } else {
                        // Tiny matrix grid dot
                        drawCircle(dotColor, radius = 1.2.dp.toPx(), center = Offset(x, y))
                    }
                }
            }
        }
    }
}

@Composable
fun AuroraGradientPattern(modifier: Modifier = Modifier) {
    val baseBrush = remember {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFF06141B),
                Color(0xFF0F1E36),
                Color(0xFF1E1032),
                Color(0xFF0B1A24)
            ),
            start = Offset(0f, 0f),
            end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(baseBrush)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Soft emerald glow wave
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF00E676).copy(alpha = 0.08f), Color.Transparent),
                    center = Offset(size.width * 0.8f, size.height * 0.25f),
                    radius = size.width * 0.7f
                ),
                radius = size.width * 0.7f,
                center = Offset(size.width * 0.8f, size.height * 0.25f)
            )

            // Soft purple wave
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFFB388FF).copy(alpha = 0.08f), Color.Transparent),
                    center = Offset(size.width * 0.2f, size.height * 0.7f),
                    radius = size.width * 0.65f
                ),
                radius = size.width * 0.65f,
                center = Offset(size.width * 0.2f, size.height * 0.7f)
            )

            // Deep turquoise highlight
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF18FFFF).copy(alpha = 0.06f), Color.Transparent),
                    center = Offset(size.width * 0.5f, size.height * 0.45f),
                    radius = size.width * 0.5f
                ),
                radius = size.width * 0.5f,
                center = Offset(size.width * 0.5f, size.height * 0.45f)
            )
        }
    }
}

@Composable
fun ParallaxChatWallpaper(
    preset: String,
    customUri: String,
    alpha: Float,
    parallaxEnabled: Boolean,
    liveVideoWallpaperEnabled: Boolean = false,
    liveVideoWallpaperUri: String = "",
    modifier: Modifier = Modifier
) {
    if (preset == "none" && (!liveVideoWallpaperEnabled || liveVideoWallpaperUri.isBlank())) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        )
        return
    }

    val context = LocalContext.current
    val animTiltX = remember { androidx.compose.animation.core.Animatable(0f) }
    val animTiltY = remember { androidx.compose.animation.core.Animatable(0f) }
    val coroutineScope = rememberCoroutineScope()

    DisposableEffect(parallaxEnabled) {
        if (!parallaxEnabled) {
            coroutineScope.launch {
                animTiltX.snapTo(0f)
                animTiltY.snapTo(0f)
            }
            return@DisposableEffect onDispose {}
        }

        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        if (sensorManager == null || sensor == null) {
            return@DisposableEffect onDispose {}
        }

        var lastUpdate = 0L
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                if (event == null) return
                val now = System.currentTimeMillis()
                if (now - lastUpdate < 40L) return // Cap at 25Hz to eliminate sensor overhead on weak devices
                lastUpdate = now

                val x = event.values[0]
                val y = event.values[1] - 4.5f
                val targetX = (-x * 3.5f).coerceIn(-28f, 28f)
                val targetY = (y * 3.5f).coerceIn(-28f, 28f)

                coroutineScope.launch {
                    animTiltX.animateTo(targetX, tween(80))
                }
                coroutineScope.launch {
                    animTiltY.animateTo(targetY, tween(80))
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        sensorManager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)

        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }

    val scaleFactor = if (parallaxEnabled) 1.15f else 1.0f

    val effectiveVideoUri = when {
        !liveVideoWallpaperEnabled -> ""
        liveVideoWallpaperUri.isNotBlank() -> liveVideoWallpaperUri
        customUri.isNotBlank() && (customUri.contains("video", ignoreCase = true) || customUri.endsWith(".mp4", ignoreCase = true) || customUri.endsWith(".webm", ignoreCase = true) || customUri.endsWith(".mkv", ignoreCase = true)) -> customUri
        preset == "custom" && customUri.isNotBlank() -> customUri
        else -> ""
    }

    val isVideoPlaying = liveVideoWallpaperEnabled && effectiveVideoUri.isNotBlank()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (isVideoPlaying) {
            LiveVideoWallpaperPlayer(
                videoUri = effectiveVideoUri,
                alpha = alpha,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        translationX = animTiltX.value
                        translationY = animTiltY.value
                        scaleX = scaleFactor
                        scaleY = scaleFactor
                    }
                    .alpha(alpha)
            ) {
                when {
                    preset == "custom" && customUri.isNotBlank() -> {
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data(customUri)
                                .crossfade(true)
                                .build(),
                            contentDescription = "Фон чата",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    else -> {
                        ProceduralWallpaper(
                            preset = preset,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    }
}
