package com.example.ui.screens.backup

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.BackupManifest
import com.example.data.repository.SelectiveExportOptions
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupScreen(
    onExportBackup: suspend (Uri, SelectiveExportOptions) -> Result<BackupManifest>,
    onInspectBackup: suspend (Uri) -> Result<BackupManifest>,
    onImportBackup: suspend (Uri, Boolean) -> Result<Unit>,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var isOperating by remember { mutableStateOf(false) }

    var exportOptions by remember { mutableStateOf(SelectiveExportOptions()) }
    var inspectResult by remember { mutableStateOf<Pair<Uri, BackupManifest>?>(null) }
    var importReplaceAll by remember { mutableStateOf(false) }

    // Launcher for creating ZIP export
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                isOperating = true
                statusMessage = "Создание выборочного архива резервной копии..."
                val res = onExportBackup(uri, exportOptions)
                statusMessage = if (res.isSuccess) {
                    val m = res.getOrNull()
                    "Экспорт успешно завершен!\nСохранено персонажей: ${m?.characterCount}, диалогов: ${m?.chatCount}, сообщений: ${m?.messageCount}, персон: ${m?.personaCount}, историй: ${m?.storyCount}"
                } else {
                    "Ошибка экспорта: ${res.exceptionOrNull()?.message}"
                }
                isOperating = false
            }
        }
    }

    // Launcher for selecting ZIP import
    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                isOperating = true
                statusMessage = "Анализ архива резервной копии..."
                val inspectRes = onInspectBackup(uri)
                if (inspectRes.isSuccess) {
                    inspectResult = uri to inspectRes.getOrNull()!!
                    statusMessage = null
                } else {
                    statusMessage = "Не удалось прочитать архив: ${inspectRes.exceptionOrNull()?.message}"
                }
                isOperating = false
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Резервные копии (ZIP)", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Export Card
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Upload, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Выборочный экспорт данных", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Выберите, какие разделы включить в ZIP-архив:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Checkboxes for each data category
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            BackupOptionRow(
                                title = "Персонажи (боты)",
                                subtitle = "Включает описания, аватары, сценарии и теги",
                                checked = exportOptions.includeCharacters,
                                onCheckedChange = { exportOptions = exportOptions.copy(includeCharacters = it) }
                            )
                            BackupOptionRow(
                                title = "Диалоги и сообщения",
                                subtitle = "Ветки чатов, память хроник и история отношений",
                                checked = exportOptions.includeChatsAndMessages,
                                onCheckedChange = { exportOptions = exportOptions.copy(includeChatsAndMessages = it) }
                            )
                            BackupOptionRow(
                                title = "Персоны пользователя",
                                subtitle = "Профили, аватары и описания от чьего лица ведется диалог",
                                checked = exportOptions.includePersonas,
                                onCheckedChange = { exportOptions = exportOptions.copy(includePersonas = it) }
                            )
                            BackupOptionRow(
                                title = "Истории и Миры (Группы ботов)",
                                subtitle = "Коллекции персонажей, лор и правила миров",
                                checked = exportOptions.includeStories,
                                onCheckedChange = { exportOptions = exportOptions.copy(includeStories = it) }
                            )
                            BackupOptionRow(
                                title = "Профили AI-провайдеров",
                                subtitle = "Эндпоинты, модели, температура и настройки",
                                checked = exportOptions.includeProviders,
                                onCheckedChange = { exportOptions = exportOptions.copy(includeProviders = it) }
                            )
                            BackupOptionRow(
                                title = "Настройки и темы оформления",
                                subtitle = "Цветовая гамма, темы, размеры шрифта и параметры чата",
                                checked = exportOptions.includeSettings,
                                onCheckedChange = { exportOptions = exportOptions.copy(includeSettings = it) }
                            )
                            if (exportOptions.includeProviders) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = 24.dp, top = 2.dp, bottom = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Включать секретные API-ключи", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                        Text("Снимите галочку для безопасной передачи бэкапа друзьям", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Checkbox(
                                        checked = exportOptions.includeApiKeys,
                                        onCheckedChange = { exportOptions = exportOptions.copy(includeApiKeys = it) }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                exportLauncher.launch("ai_roleplay_backup_${System.currentTimeMillis()}.zip")
                            },
                            enabled = !isOperating,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.SaveAlt, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Экспортировать в ZIP")
                        }
                    }
                }
            }

            // Import Card
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Импорт из ZIP-архива", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Восстановление персонажей, историй и диалогов из резервной копии. Перед импортом будет показана подробная сводка содержимого архива.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                importLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*"))
                            },
                            enabled = !isOperating,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.FolderOpen, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Выбрать ZIP-файл для импорта")
                        }
                    }
                }
            }

            // Status message
            if (statusMessage != null || isOperating) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isOperating) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                            }
                            Text(
                                text = statusMessage ?: "Выполняется...",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }

    // Inspect & Confirm Import Dialog
    if (inspectResult != null) {
        val (uri, manifest) = inspectResult!!
        AlertDialog(
            onDismissRequest = { inspectResult = null },
            icon = { Icon(Icons.Default.FolderZip, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(32.dp)) },
            title = { Text("Содержимое резервной копии", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("В архиве найдено:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    Text("• Персонажей: ${manifest.characterCount}")
                    Text("• Диалогов: ${manifest.chatCount}")
                    Text("• Сообщений: ${manifest.messageCount}")
                    Text("• Персон: ${manifest.personaCount}")
                    Text("• Историй / Миров: ${manifest.storyCount}")
                    Text("• Комиксов: ${manifest.comicCount}")
                    Text("• AI-провайдеров: ${manifest.providerCount}")
                    Text("• Настройки и темы оформления: ${if (manifest.hasSettings) "Да" else "Нет"}")

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    Text("Режим импорта:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (importReplaceAll) "Заменить все текущие данные" else "Объединить (добавить к текущим)", style = MaterialTheme.typography.bodySmall)
                        Switch(
                            checked = importReplaceAll,
                            onCheckedChange = { importReplaceAll = it }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val toImportUri = uri
                        val replace = importReplaceAll
                        inspectResult = null
                        coroutineScope.launch {
                            isOperating = true
                            statusMessage = "Импорт данных..."
                            val res = onImportBackup(toImportUri, replace)
                            statusMessage = if (res.isSuccess) {
                                "Импорт успешно завершен! Все данные восстановлены."
                            } else {
                                "Ошибка импорта: ${res.exceptionOrNull()?.message}"
                            }
                            isOperating = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Text("Импортировать")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { inspectResult = null }) {
                    Text("Отмена")
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }
}

@Composable
private fun BackupOptionRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}

