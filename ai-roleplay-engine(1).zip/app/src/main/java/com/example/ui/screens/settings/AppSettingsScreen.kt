package com.example.ui.screens.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ai.engine.RoleplayPresets
import com.example.ai.engine.RoleplayPromptBuilder
import com.example.ui.studio.studioElement
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.R
import com.example.data.datastore.UserSettings
import com.example.ui.components.*
import com.example.ui.components.AppLogo
import com.example.ui.components.ParallaxChatWallpaper
import com.example.ui.components.WallpaperPresetsList
import com.example.ui.theme.AccentPresets
import com.example.ui.theme.AvailableBaseFonts
import com.example.ui.theme.FontHelper
import com.example.ui.studio.StudioLayoutManager
import com.example.util.AppStrings
import com.example.util.LanguagePackInfo
import kotlinx.coroutines.launch

data class SettingsTabItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val badge: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppSettingsScreen(
    settings: UserSettings,
    onUpdateSettings: (UserSettings) -> Unit,
    onOpenBackup: () -> Unit,
    onOpenProviders: () -> Unit,
    providers: List<com.example.data.local.entity.AiProviderProfileEntity> = emptyList(),
    onOpenStudioMode: () -> Unit = {},
    onOpenGeminiDebug: () -> Unit = {},
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val activeTabByScroll by remember {
        derivedStateOf {
            val firstVisible = listState.firstVisibleItemIndex
            when {
                firstVisible >= 30 -> 4
                firstVisible >= 25 -> 3
                firstVisible >= 18 -> 2
                firstVisible >= 11 -> 1
                else -> 0
            }
        }
    }
    val settingsTabs = listOf(
        SettingsTabItem("Оформление", "Темы & цвет", Icons.Default.Palette),
        SettingsTabItem("Обои", "Фоны & эффект", Icons.Default.Wallpaper),
        SettingsTabItem("ИИ & Модели", "Провайдеры & сеть", Icons.Default.Psychology),
        SettingsTabItem("Поведение", "Чат & токены", Icons.Default.Forum, badge = "AI"),
        SettingsTabItem("Система", "Бэкап & инфо", Icons.Default.SettingsBackupRestore)
    )
    var showCustomHexDialog by remember { mutableStateOf(false) }
    var showDefaultPromptDialog by remember { mutableStateOf(false) }
    var showDownloadPromptConfirmDialog by remember { mutableStateOf(false) }
    var isDownloadingPrompt by remember { mutableStateOf(false) }
    var showFrameRepositoryDialog by remember { mutableStateOf(false) }

    val customWallpaperPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val savedPath = com.example.util.ImageStorageHelper.saveWallpaperFile(context, uri)
            if (savedPath != null) {
                val updated = settings.withAddedCustomWallpaper(savedPath)
                onUpdateSettings(updated)
            }
        }
    }

    val fontFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val res = FontHelper.importCustomFont(context, uri)
            if (res != null) {
                onUpdateSettings(
                    settings.copy(
                        fontFamilyChoice = "custom",
                        customFontPath = res.first,
                        customFontName = res.second
                    )
                )
                Toast.makeText(context, "Шрифт «${res.second}» успешно загружен!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val liveVideoWallpaperPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val savedPath = com.example.util.ImageStorageHelper.saveWallpaperFile(context, uri) ?: uri.toString()
            onUpdateSettings(
                settings.copy(
                    liveVideoWallpaperUri = savedPath,
                    liveVideoWallpaperEnabled = true
                )
            )
            Toast.makeText(context, "Живые видео-обои установлены!", Toast.LENGTH_SHORT).show()
        }
    }

    val customAppBackgroundPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val savedPath = com.example.util.ImageStorageHelper.saveWallpaperFile(context, uri) ?: uri.toString()
            onUpdateSettings(
                settings.copy(
                    appThemeBackgroundPreset = "custom",
                    appCustomBackgroundUri = savedPath
                )
            )
            Toast.makeText(context, "Фон приложения установлен!", Toast.LENGTH_SHORT).show()
        }
    }

    if (showCustomHexDialog) {
        var hexInput by remember {
            mutableStateOf(String.format("#%06X", 0xFFFFFF and settings.accentColorLong.toInt()))
        }
        var parseError by remember { mutableStateOf(false) }

        val parsedColor: Color? = remember(hexInput) {
            try {
                val clean = hexInput.trim().removePrefix("#")
                if (clean.length == 6) {
                    val colorInt = clean.toLong(16)
                    parseError = false
                    Color(0xFF000000 or colorInt)
                } else {
                    parseError = true
                    null
                }
            } catch (_: Exception) {
                parseError = true
                null
            }
        }

        AlertDialog(
            onDismissRequest = { showCustomHexDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Palette, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Свой HEX цвет", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Введите произвольный шестнадцатеричный код цвета в формате #RRGGBB:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    
                    OutlinedTextField(
                        value = hexInput,
                        onValueChange = { hexInput = it },
                        label = { Text("HEX код") },
                        placeholder = { Text("#7C3AED") },
                        singleLine = true,
                        isError = parseError,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Предпросмотр цвета:", style = MaterialTheme.typography.bodyMedium)
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(parsedColor ?: Color.Gray)
                                .border(2.dp, MaterialTheme.colorScheme.outline, CircleShape)
                        )
                    }

                    if (parseError) {
                        Text("Пожалуйста, введите корректный 6-значный HEX (например, #9333EA)", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clean = hexInput.trim().removePrefix("#")
                        try {
                            val colorLong = 0xFF000000L or clean.toLong(16)
                            onUpdateSettings(settings.copy(accentColorLong = colorLong))
                            showCustomHexDialog = false
                        } catch (_: Exception) {}
                    },
                    enabled = !parseError && parsedColor != null
                ) {
                    Text("Применить")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomHexDialog = false }) {
                    Text("Отмена")
                }
            }
        )
    }

    if (showDefaultPromptDialog) {
        val defaultTemplate = remember {
            com.example.ai.engine.RoleplayPromptBuilder.getDefaultSystemPromptTemplate("{{char}}")
        }

        AlertDialog(
            onDismissRequest = { showDefaultPromptDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Terminal,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Стандартный системный промпт", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Этот шаблон используется по умолчанию, когда поле пользовательского промпта пустое. Переменные {{char}} и {{user}} заменяются на имена персонажа и персоны.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 200.dp, max = 380.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    ) {
                        SelectionContainer {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                Text(
                                    text = defaultTemplate,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                        fontSize = 11.5.sp,
                                        lineHeight = 16.sp
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Default System Prompt", defaultTemplate)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Стандартный промпт скопирован", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Копировать")
                    }

                    Button(
                        onClick = {
                            onUpdateSettings(settings.copy(customSystemPrompt = defaultTemplate))
                            showDefaultPromptDialog = false
                            Toast.makeText(context, "Вставлено как пользовательский промпт", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Text("Вставить в поле")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showDefaultPromptDialog = false }) {
                    Text("Закрыть")
                }
            }
        )
    }

    if (showDownloadPromptConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDownloadPromptConfirmDialog = false },
            icon = {
                Icon(
                    Icons.Default.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = {
                Text(
                    "Скачать системный промпт?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Внимание! Текущий системный промпт будет удален и заменен на актуальный системный промпт из официального репозитория GitHub.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "Все ваши персональные изменения системного промпта будут перезаписаны!",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                    Text(
                        "Продолжить загрузку и замену?",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDownloadPromptConfirmDialog = false
                        isDownloadingPrompt = true
                        coroutineScope.launch {
                            val result = com.example.util.SystemPromptManager.fetchRemoteSystemPrompt()
                            isDownloadingPrompt = false
                            if (result.isSuccess) {
                                val remote = result.getOrNull()
                                if (remote != null && remote.prompt.isNotBlank()) {
                                    onUpdateSettings(
                                        settings.copy(
                                            customSystemPrompt = remote.prompt,
                                            systemPromptVersion = remote.version,
                                            downloadedSystemPrompt = remote.prompt,
                                            isSystemPromptUserModified = false,
                                            isSystemPromptFirstLaunchDone = true
                                        )
                                    )
                                    Toast.makeText(
                                        context,
                                        "Системный промпт (версия ${remote.version}) успешно установлен!",
                                        Toast.LENGTH_LONG
                                    ).show()
                                } else {
                                    Toast.makeText(context, "Не удалось разобрать системный промпт", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                Toast.makeText(
                                    context,
                                    "Ошибка скачивания: ${result.exceptionOrNull()?.localizedMessage ?: "Нет подключения к сети"}",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Скачать и заменить")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDownloadPromptConfirmDialog = false }) {
                    Text("Отмена")
                }
            }
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                modifier = Modifier.studioElement("settings_top_bar"),
                title = { Text("Настройки приложения", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Left Navigation Rail / Vertical Tabs
            Surface(
                modifier = Modifier
                    .studioElement("settings_category_nav")
                    .width(82.dp)
                    .fillMaxHeight(),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    settingsTabs.forEachIndexed { index, tabItem ->
                        val isSelected = activeTabByScroll == index
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    val targetIndex = when (index) {
                                        0 -> 1
                                        1 -> 11
                                        2 -> 18
                                        3 -> 25
                                        4 -> 30
                                        else -> 0
                                    }
                                    coroutineScope.launch {
                                        listState.animateScrollToItem(targetIndex)
                                    }
                                },
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(vertical = 8.dp, horizontal = 2.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(contentAlignment = Alignment.TopEnd) {
                                    Icon(
                                        imageVector = tabItem.icon,
                                        contentDescription = tabItem.title,
                                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    if (tabItem.badge != null) {
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.offset(x = 8.dp, y = (-4).dp)
                                        ) {
                                            Text(
                                                text = tabItem.badge,
                                                fontSize = 7.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White,
                                                modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = tabItem.title,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    maxLines = 2,
                                    lineHeight = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            VerticalDivider(
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                modifier = Modifier.fillMaxHeight()
            )

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                // 0. Interface Variant, Typography & Liquid Glass Section
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Dashboard, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Вариант интерфейса",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "Выберите компоновку главного экрана приложения",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Variant cards
                            val variants = listOf(
                                Triple("classic", "Классический мессенджер", "Традиционный вид со списком диалогов, вкладками и категориями"),
                                Triple("vault_hub", "Новый Untitled", "Главный экран — витрина персонажей из box.json, баннеры, быстрые действия и диалоги")
                            )

                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                variants.forEach { (id, title, desc) ->
                                    val isSelected = settings.uiVariant == id || (id == "classic" && settings.uiVariant != "vault_hub")
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                                        border = BorderStroke(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { onUpdateSettings(settings.copy(uiVariant = id)) }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            RadioButton(
                                                selected = isSelected,
                                                onClick = { onUpdateSettings(settings.copy(uiVariant = id)) }
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                Text(desc, fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                            }

                            if (settings.uiVariant == "vault_hub") {
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    "Основная вкладка Новый Untitled:",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    val startTabs = listOf(
                                        "general" to "Общее (Хранилище)",
                                        "chats" to "Чаты (Диалоги)"
                                    )
                                    startTabs.forEach { (tabId, label) ->
                                        val isSelected = settings.vaultHubStartTab == tabId
                                        FilterChip(
                                            selected = isSelected,
                                            onClick = { onUpdateSettings(settings.copy(vaultHubStartTab = tabId)) },
                                            label = { Text(label, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                            leadingIcon = if (isSelected) {
                                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                            } else null,
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                            Spacer(modifier = Modifier.height(14.dp))

                            // Typography / Fonts Section
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.TextFields, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Шрифты приложения:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(8.dp))

                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(AvailableBaseFonts) { fontOpt ->
                                    val isSelected = settings.fontFamilyChoice == fontOpt.id
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { onUpdateSettings(settings.copy(fontFamilyChoice = fontOpt.id)) },
                                        label = { Text(fontOpt.nameRu, fontSize = 11.sp, fontFamily = fontOpt.fontFamily) },
                                        leadingIcon = if (isSelected) {
                                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                        } else null,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            val isCustomFont = settings.fontFamilyChoice == "custom"
                            FilledTonalButton(
                                onClick = { fontFilePicker.launch("*/*") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (settings.customFontName.isNotBlank()) "Импортирован: ${settings.customFontName} (Сменить .TTF)" else "➕ Импортировать свой шрифт (.ttf / .otf)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            if (settings.customFontName.isNotBlank() && !isCustomFont) {
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedButton(
                                    onClick = { onUpdateSettings(settings.copy(fontFamilyChoice = "custom")) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Активировать ${settings.customFontName}", fontSize = 12.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                            Spacer(modifier = Modifier.height(14.dp))

                            // 🔮 TRANSPARENCY & GLASSMORPHISM CONTROLS
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text("Прозрачность интерфейса", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(
                                            "Элегантная полупрозрачность и матовый эффект для диалогов и панелей",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                                Switch(
                                    checked = settings.glassmorphismEnabled,
                                    onCheckedChange = { onUpdateSettings(settings.copy(glassmorphismEnabled = it)) }
                                )
                            }

                            if (settings.glassmorphismEnabled) {
                                Spacer(modifier = Modifier.height(12.dp))

                                // ✨ REAL-TIME INTERACTIVE TRANSPARENCY LIVE PREVIEW CARD
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(120.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(
                                            Brush.linearGradient(
                                                listOf(
                                                    Color(0xFF6366F1),
                                                    Color(0xFFA855F7),
                                                    Color(0xFFEC4899),
                                                    Color(0xFF3B82F6)
                                                )
                                            )
                                        )
                                        .padding(12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    LiquidGlassSurface(
                                        userSettings = settings,
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column {
                                                Text("✨ Предпросмотр прозрачности", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = if (settings.wallpaperTone == "light") Color.Black else Color.White)
                                                Text("Плавная матовая подложка с мягкой гранью", fontSize = 10.5.sp, color = if (settings.wallpaperTone == "light") Color(0xFF334155) else Color(0xFFCBD5E1))
                                            }
                                            LiquidGlassPillButton(
                                                text = "Тест кнопки",
                                                onClick = {},
                                                userSettings = settings,
                                                fontSize = 10.5.sp
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Transparency Presets
                                Text("Пресеты прозрачности:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    val glassPresets = listOf(
                                        "Минимальная" to 0.88f,
                                        "Сбалансированная" to 0.70f,
                                        "Высокая" to 0.50f,
                                        "Ультрапрозрачность" to 0.30f
                                    )
                                    items(glassPresets.size) { idx ->
                                        val (name, value) = glassPresets[idx]
                                        OutlinedButton(
                                            onClick = {
                                                onUpdateSettings(settings.copy(glassAlpha = value))
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text(name, fontSize = 10.5.sp)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Slider: Alpha
                                Text("Степень прозрачности: ${(settings.glassAlpha * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = settings.glassAlpha,
                                    onValueChange = { onUpdateSettings(settings.copy(glassAlpha = it)) },
                                    valueRange = 0.15f..0.95f
                                )

                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Тон подложки прозрачности:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    FilterChip(
                                        selected = settings.wallpaperTone != "light",
                                        onClick = { onUpdateSettings(settings.copy(wallpaperTone = "dark")) },
                                        label = { Text("Тёмная подложка", fontSize = 11.sp) },
                                        modifier = Modifier.weight(1f)
                                    )
                                    FilterChip(
                                        selected = settings.wallpaperTone == "light",
                                        onClick = { onUpdateSettings(settings.copy(wallpaperTone = "light")) },
                                        label = { Text("Светлая подложка", fontSize = 11.sp) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. App Icons in Different Colors
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AppShortcut, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Варианты иконки приложения", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    Text("Выберите цвет и стиль значка приложения", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            val iconVariants = listOf(
                                Triple("purple", "Фиолетовый Неон", Color(0xFFC084FC)),
                                Triple("cyan", "Кибер Циан", Color(0xFF00F0FF)),
                                Triple("pink", "Сакура Розовый", Color(0xFFF472B6)),
                                Triple("emerald", "Изумрудный Нефрит", Color(0xFF34D399)),
                                Triple("crimson", "Королевский Рубин", Color(0xFFFB7185)),
                                Triple("gold", "Имперское Золото", Color(0xFFF59E0B)),
                                Triple("dark", "Глубокий Обсидиан", Color(0xFF334155)),
                                Triple("arctic", "Арктический Лёд", Color(0xFF7DD3FC))
                            )

                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                iconVariants.chunked(2).forEach { rowIcons ->
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        rowIcons.forEach { (id, label, col) ->
                                            val isSelected = settings.appIconVariant == id
                                            Surface(
                                                shape = RoundedCornerShape(12.dp),
                                                color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface,
                                                border = BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                                                modifier = Modifier.weight(1f).clickable { onUpdateSettings(settings.copy(appIconVariant = id)) }
                                            ) {
                                                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                                    Box(
                                                        modifier = Modifier.size(28.dp).clip(CircleShape).background(col),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                                    }
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(label, fontSize = 11.5.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal, maxLines = 1, modifier = Modifier.weight(1f))
                                                    if (isSelected) {
                                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 3. Theme and Background Styling with Video Live Wallpaper
                item {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                                modifier = Modifier
                                    .studioElement("settings_theme_card")
                                    .fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Palette,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "Оформление и фоны приложения",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Text(
                                                text = "13 стилей палитры, фоны из галереи и живые видео-обои",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    // Theme cards grid
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        com.example.ui.theme.AvailableThemes.chunked(2).forEach { rowThemes ->
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                rowThemes.forEach { themeOption ->
                                                    val isSelected = settings.themeMode == themeOption.id
                                                    Surface(
                                                        shape = RoundedCornerShape(12.dp),
                                                        color = themeOption.previewSurface,
                                                        border = BorderStroke(
                                                            width = if (isSelected) 2.5.dp else 1.dp,
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                                                        ),
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .clickable {
                                                                onUpdateSettings(settings.copy(themeMode = themeOption.id))
                                                            }
                                                    ) {
                                                        Row(
                                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Box(
                                                                modifier = Modifier
                                                                    .size(24.dp)
                                                                    .clip(CircleShape)
                                                                    .background(themeOption.previewBg)
                                                                    .border(2.dp, themeOption.previewAccent, CircleShape)
                                                            )
                                                            Spacer(modifier = Modifier.width(8.dp))
                                                            Text(
                                                                text = themeOption.name,
                                                                style = MaterialTheme.typography.bodySmall,
                                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                                color = if (themeOption.isDark) Color(0xFFEEEEEE) else Color(0xFF222222),
                                                                maxLines = 1,
                                                                modifier = Modifier.weight(1f)
                                                            )
                                                            if (isSelected) {
                                                                Icon(
                                                                    imageVector = Icons.Default.CheckCircle,
                                                                    contentDescription = null,
                                                                    tint = MaterialTheme.colorScheme.primary,
                                                                    modifier = Modifier.size(18.dp)
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                                if (rowThemes.size == 1) {
                                                    Spacer(modifier = Modifier.weight(1f))
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Custom Static Wallpaper from Gallery
                                    Button(
                                        onClick = { customAppBackgroundPicker.launch("image/*") },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("➕ Выбрать фоновую картинку приложения", fontSize = 12.sp)
                                    }
                                }
                            }
                        }

                        item {
                            Column(
                                modifier = Modifier
                                    .studioElement("settings_accent_card")
                                    .fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Палитра акцентных цветов", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                        Text("Выберите акцент интерфейса или задайте свой HEX код", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    FilledTonalButton(
                                        onClick = { showCustomHexDialog = true },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Icon(Icons.Default.Colorize, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("HEX", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Beautiful grid of color circles with names
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AccentPresets.chunked(4).forEach { rowPresets ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            rowPresets.forEach { (name, colorValue) ->
                                                val isSelected = settings.accentColorLong == colorValue
                                                Column(
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    modifier = Modifier
                                                        .width(76.dp)
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .clickable { onUpdateSettings(settings.copy(accentColorLong = colorValue)) }
                                                        .padding(vertical = 4.dp)
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(38.dp)
                                                            .clip(CircleShape)
                                                            .background(Color(colorValue))
                                                            .then(
                                                                if (isSelected) Modifier.border(
                                                                    BorderStroke(3.dp, MaterialTheme.colorScheme.onSurface),
                                                                    CircleShape
                                                                ) else Modifier
                                                            ),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        if (isSelected) {
                                                            Icon(
                                                                imageVector = Icons.Default.Check,
                                                                contentDescription = null,
                                                                tint = if (Color(colorValue).red * 0.299 + Color(colorValue).green * 0.587 + Color(colorValue).blue * 0.114 > 0.6) Color.Black else Color.White,
                                                                modifier = Modifier.size(20.dp)
                                                            )
                                                        }
                                                    }
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(
                                                        text = name,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontSize = 10.sp,
                                                        maxLines = 1,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                                    )
                                                }
                                            }
                                            if (rowPresets.size < 4) {
                                                repeat(4 - rowPresets.size) {
                                                    Spacer(modifier = Modifier.width(76.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        }

                        item {
                            Text("Размер шрифта", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Шрифт сообщений: ${settings.fontSizeSp} sp", style = MaterialTheme.typography.bodyMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilledTonalIconButton(
                                        onClick = { if (settings.fontSizeSp > 12) onUpdateSettings(settings.copy(fontSizeSp = settings.fontSizeSp - 1)) }
                                    ) {
                                        Text("A-", fontWeight = FontWeight.Bold)
                                    }
                                    FilledTonalIconButton(
                                        onClick = { if (settings.fontSizeSp < 24) onUpdateSettings(settings.copy(fontSizeSp = settings.fontSizeSp + 1)) }
                                    ) {
                                        Text("A+", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        item {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        }

                        item {
                            Column(
                                modifier = Modifier
                                    .studioElement("settings_chat_view_card")
                                    .fillMaxWidth()
                            ) {
                                Text("Стиль диалогов", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("bubbles" to "Пузыри сообщений", "novel" to "Литературный сценарий").forEach { (styleKey, label) ->
                                        FilterChip(
                                            modifier = Modifier.weight(1f),
                                            selected = settings.bubbleStyle == styleKey,
                                            onClick = { onUpdateSettings(settings.copy(bubbleStyle = styleKey)) },
                                            label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Аватарки в чате", fontWeight = FontWeight.Bold)
                                        Text("Отображать аватарки возле сообщений персонажа", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Switch(
                                        checked = settings.showAvatarInChat,
                                        onCheckedChange = { onUpdateSettings(settings.copy(showAvatarInChat = it)) }
                                    )
                                }
                            }
                        }

                        // Literary (Novel) Mode Customization Section
                        if (settings.bubbleStyle == "novel") {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = "📖 Литературный сценарий: Настройки",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))

                                        Text(
                                            text = "Выравнивание текста бота в чате:",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            listOf(
                                                "left" to "⬅️ Слева",
                                                "center" to "↔️ Посередине",
                                                "right" to "➡️ Справа"
                                            ).forEach { (alignKey, alignLabel) ->
                                                FilterChip(
                                                    modifier = Modifier.weight(1f),
                                                    selected = settings.novelTextAlignment == alignKey,
                                                    onClick = { onUpdateSettings(settings.copy(novelTextAlignment = alignKey)) },
                                                    label = { Text(alignLabel, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp) },
                                                    shape = RoundedCornerShape(8.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                                        Spacer(modifier = Modifier.height(8.dp))

                                        Text(
                                            text = "Полосочка-разделитель реплик",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "Кастомизация разделительной линии между репликами",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Отображать полосочку", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                                        Switch(
                                            checked = settings.novelDividerEnabled,
                                            onCheckedChange = { onUpdateSettings(settings.copy(novelDividerEnabled = it)) }
                                        )
                                    }

                                    if (settings.novelDividerEnabled) {
                                        Spacer(modifier = Modifier.height(8.dp))

                                        // Width %
                                        Text(
                                            text = "Ширина полосы: ${settings.novelDividerWidthPercent}%",
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                        Slider(
                                            value = settings.novelDividerWidthPercent.toFloat(),
                                            onValueChange = { onUpdateSettings(settings.copy(novelDividerWidthPercent = it.toInt())) },
                                            valueRange = 10f..100f,
                                            steps = 17
                                        )

                                        // Thickness dp
                                        Text(
                                            text = "Толщина полосы: ${settings.novelDividerThicknessDp} dp",
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                        Slider(
                                            value = settings.novelDividerThicknessDp.toFloat(),
                                            onValueChange = { onUpdateSettings(settings.copy(novelDividerThicknessDp = it.toInt())) },
                                            valueRange = 1f..5f,
                                            steps = 3
                                        )

                                        // Alpha %
                                        Text(
                                            text = "Прозрачность: ${(settings.novelDividerAlpha * 100).toInt()}%",
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                        Slider(
                                            value = settings.novelDividerAlpha,
                                            onValueChange = { onUpdateSettings(settings.copy(novelDividerAlpha = it)) },
                                            valueRange = 0.1f..1.0f
                                        )

                                        // Color Presets
                                        Text("Цвет полосочки", style = MaterialTheme.typography.labelMedium)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        val colorPresets = listOf(
                                            "#FFFFFF" to "Белый",
                                            "#D0BCFF" to "Акцент",
                                            "#FFD54F" to "Золотой",
                                            "#B0BEC5" to "Серый",
                                            "#80CBC4" to "Бирюза",
                                            "#F48FB1" to "Розовый"
                                        )
                                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            items(colorPresets.size) { idx ->
                                                val (hex, name) = colorPresets[idx]
                                                val isSelected = settings.novelDividerColorHex.equals(hex, ignoreCase = true)
                                                FilterChip(
                                                    selected = isSelected,
                                                    onClick = { onUpdateSettings(settings.copy(novelDividerColorHex = hex)) },
                                                    label = { Text(name, fontSize = 11.sp) },
                                                    shape = RoundedCornerShape(6.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))
                                        // Live Mini-Preview of Divider
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                                .padding(vertical = 12.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            val parsedColor = try {
                                                Color(android.graphics.Color.parseColor(settings.novelDividerColorHex))
                                            } catch (_: Exception) { Color.White }

                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth(settings.novelDividerWidthPercent / 100f)
                                                    .height(settings.novelDividerThicknessDp.dp)
                                                    .background(
                                                        color = parsedColor.copy(alpha = settings.novelDividerAlpha),
                                                        shape = RoundedCornerShape(2.dp)
                                                    )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }


                        item {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        }

                        item {
                            Text("Анимация прокрутки чата", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Эффект авто-прокрутки и перемещения к новым сообщениям", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(8.dp))

                            val scrollAnimations = listOf(
                                "spring" to "🌸 Плавная пружина (Spring / Рекомендуется)",
                                "bounce" to "⚡ Упругий отскок (Bouncy)",
                                "cinematic" to "🎬 Кинематографичная (Cinematic glide)",
                                "instant" to "🚀 Без анимации (Мгновенный переход)"
                            )

                            scrollAnimations.forEach { (key, label) ->
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (settings.chatScrollAnimation == key) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else Color.Transparent,
                                    border = BorderStroke(
                                        1.dp,
                                        if (settings.chatScrollAnimation == key) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                        .clickable { onUpdateSettings(settings.copy(chatScrollAnimation = key)) }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = settings.chatScrollAnimation == key,
                                            onClick = { onUpdateSettings(settings.copy(chatScrollAnimation = key)) }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(label, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }

                    // 5. Interface Animation Settings Card
                    item {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Animation,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Анимации переходов между вкладками и чатом",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "Стили переходов между вкладками, хранилищем и входом/выходом из чата с предпросмотром",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                // Interactive Live Preview for Tab Transitions
                                TabTransitionInteractivePreview(
                                    animationStyle = settings.tabSwitchAnimation,
                                    durationMs = settings.tabSwitchDurationMs,
                                    accentColor = Color(settings.accentColorLong)
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                // Duration Slider & Presets
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.55f),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.18f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(
                                                    text = "Длительность анимации перехода",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = if (settings.tabSwitchAnimation == "instant") "В режиме «Мгновенно» задержка отключена" else "Скорость срабатывания выбранного эффекта (80 – 750 мс)",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = MaterialTheme.colorScheme.primaryContainer
                                            ) {
                                                Text(
                                                    text = if (settings.tabSwitchAnimation == "instant") "0 мс" else "${settings.tabSwitchDurationMs} мс",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }

                                        Slider(
                                            value = settings.tabSwitchDurationMs.toFloat().coerceIn(80f, 750f),
                                            onValueChange = { newVal ->
                                                val newAnim = if (settings.tabSwitchAnimation == "instant") "smooth_slide" else settings.tabSwitchAnimation
                                                onUpdateSettings(
                                                    settings.copy(
                                                        tabSwitchAnimation = newAnim,
                                                        tabSwitchDurationMs = newVal.toInt()
                                                    )
                                                )
                                            },
                                            valueRange = 80f..750f
                                        )

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            listOf(
                                                "140 мс (Быстро)" to 140,
                                                "260 мс (Стандарт)" to 260,
                                                "420 мс (Плавно)" to 420,
                                                "600 мс (Кино)" to 600
                                            ).forEach { (label, ms) ->
                                                val selected = settings.tabSwitchAnimation != "instant" && kotlin.math.abs(settings.tabSwitchDurationMs - ms) <= 20
                                                FilterChip(
                                                    selected = selected,
                                                    onClick = {
                                                        val newAnim = if (settings.tabSwitchAnimation == "instant") "smooth_slide" else settings.tabSwitchAnimation
                                                        onUpdateSettings(
                                                            settings.copy(
                                                                tabSwitchAnimation = newAnim,
                                                                tabSwitchDurationMs = ms
                                                            )
                                                        )
                                                    },
                                                    label = { Text(label, fontSize = 10.5.sp) }
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Text(
                                    text = "Варианты анимаций переключения вкладок:",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    TabTransitionHelper.availableAnimations.forEach { option ->
                                        val isSelected = settings.tabSwitchAnimation == option.key
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.45f),
                                            border = BorderStroke(
                                                1.dp,
                                                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.18f)
                                            ),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .clickable { onUpdateSettings(settings.copy(tabSwitchAnimation = option.key)) }
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                                            ) {
                                                RadioButton(
                                                    selected = isSelected,
                                                    onClick = { onUpdateSettings(settings.copy(tabSwitchAnimation = option.key)) }
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Text(
                                                            text = option.title,
                                                            style = MaterialTheme.typography.bodyMedium,
                                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Surface(
                                                            shape = RoundedCornerShape(6.dp),
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                                                        ) {
                                                            Text(
                                                                text = option.badge,
                                                                fontSize = 9.5.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                            )
                                                        }
                                                    }
                                                    Text(
                                                        text = option.subtitle,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        fontSize = 11.5.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Text(
                                    text = "Анимация подсветки хотбара:",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(6.dp))

                                listOf(
                                    "spring" to "🎨 Плавный пружинный эффект",
                                    "instant" to "⚡ Мгновенное переключение без анимации"
                                ).forEach { (key, label) ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { onUpdateSettings(settings.copy(hotbarAnimation = key)) }
                                            .padding(vertical = 4.dp)
                                    ) {
                                        RadioButton(
                                            selected = settings.hotbarAnimation == key,
                                            onClick = { onUpdateSettings(settings.copy(hotbarAnimation = key)) }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(label, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                                        Text(
                                            text = "Отображать панель навигации (хотбар)",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Включить или скрыть нижнюю плавающую панель переключения разделов",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Switch(
                                        checked = settings.isHotbarVisible,
                                        onCheckedChange = { onUpdateSettings(settings.copy(isHotbarVisible = it)) }
                                    )
                                }
                            }
                        }
                    }

                    // Dedicated Wallpapers Management Section
                    val customWallpapers = settings.getCustomWallpapersList()

                        // 1. Live Video Wallpaper (BETA) Switch
                        item {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (settings.liveVideoWallpaperEnabled) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, if (settings.liveVideoWallpaperEnabled) MaterialTheme.colorScheme.primary.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("Живые обои (Видеофон)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Surface(shape = RoundedCornerShape(4.dp), color = MaterialTheme.colorScheme.primary) {
                                                    Text("BETA", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp))
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                "При включении позволяет выбирать видеофайлы (.mp4 / .webm) в качестве бесшовного анимированного фона для диалогов",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Switch(
                                            checked = settings.liveVideoWallpaperEnabled,
                                            onCheckedChange = { onUpdateSettings(settings.copy(liveVideoWallpaperEnabled = it)) }
                                        )
                                    }
                                }
                            }
                        }

                        item {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                "Пользовательские фоны",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Surface(
                                                shape = CircleShape,
                                                color = MaterialTheme.colorScheme.primary
                                            ) {
                                                Text(
                                                    "${customWallpapers.size}",
                                                    color = MaterialTheme.colorScheme.onPrimary,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            if (settings.liveVideoWallpaperEnabled) "Загружайте изображения или видео (.mp4) для фона диалогов" else "Загружайте любые картинки, арты или фотографии и применяйте их для диалогов",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Button(
                                        onClick = {
                                            customWallpaperPicker.launch(if (settings.liveVideoWallpaperEnabled) "*/*" else "image/*")
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                                    ) {
                                        Icon(if (settings.liveVideoWallpaperEnabled) Icons.Default.VideoLibrary else Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (settings.liveVideoWallpaperEnabled) "+ Фото/Видео" else "+ Загрузить", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        if (customWallpapers.isEmpty()) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(24.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(
                                            Icons.Default.Wallpaper,
                                            contentDescription = null,
                                            modifier = Modifier.size(48.dp),
                                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                                        )
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Text(
                                            "У вас пока нет загруженных фонов",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyLarge
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            if (settings.liveVideoWallpaperEnabled) "Нажмите «+ Фото/Видео» выше, чтобы выбрать картинку или видеофайл из устройства." else "Нажмите «+ Загрузить» выше, чтобы выбрать картинку из галереи устройства. Она сохранится локально и не исчезнет.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        )
                                    }
                                }
                            }
                        } else {
                            item {
                                Text("Ваша коллекция загруженных фонов:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(8.dp))

                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    items(customWallpapers) { wallpaperPath ->
                                        val isSelected = settings.chatWallpaperPreset == "custom" && settings.customWallpaperUri == wallpaperPath
                                        val isVideo = wallpaperPath.contains("video", ignoreCase = true) || wallpaperPath.endsWith(".mp4", ignoreCase = true) || wallpaperPath.endsWith(".webm", ignoreCase = true)

                                        Surface(
                                            shape = RoundedCornerShape(14.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant,
                                            border = BorderStroke(2.5.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                                            modifier = Modifier
                                                .width(130.dp)
                                                .height(180.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .clickable {
                                                    onUpdateSettings(
                                                        settings.copy(
                                                            chatWallpaperPreset = "custom",
                                                            customWallpaperUri = wallpaperPath,
                                                            liveVideoWallpaperUri = if (isVideo) wallpaperPath else settings.liveVideoWallpaperUri
                                                        )
                                                    )
                                                }
                                        ) {
                                            Box(modifier = Modifier.fillMaxSize()) {
                                                if (isVideo) {
                                                    LiveVideoWallpaperPlayer(
                                                        videoUri = wallpaperPath,
                                                        alpha = 0.9f,
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                } else {
                                                    AsyncImage(
                                                        model = ImageRequest.Builder(context)
                                                            .data(wallpaperPath)
                                                            .crossfade(true)
                                                            .build(),
                                                        contentDescription = "Custom wallpaper",
                                                        contentScale = ContentScale.Crop,
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                }

                                                // Top-right selection badge or Video indicator
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(6.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.Top
                                                ) {
                                                    if (isVideo) {
                                                        Surface(
                                                            shape = RoundedCornerShape(4.dp),
                                                            color = Color.Black.copy(alpha = 0.7f)
                                                        ) {
                                                            Text(
                                                                "🎬 Видео",
                                                                fontSize = 9.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = Color.White,
                                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                            )
                                                        }
                                                    } else {
                                                        Spacer(modifier = Modifier.width(1.dp))
                                                    }

                                                    if (isSelected) {
                                                        Surface(
                                                            shape = CircleShape,
                                                            color = MaterialTheme.colorScheme.primary,
                                                            modifier = Modifier.size(24.dp)
                                                        ) {
                                                            Icon(
                                                                Icons.Default.Check,
                                                                contentDescription = "Выбрано",
                                                                tint = Color.White,
                                                                modifier = Modifier.padding(4.dp)
                                                            )
                                                        }
                                                    }
                                                }

                                                // Bottom bar with Delete and Select indicator
                                                Surface(
                                                    shape = RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp),
                                                    color = Color.Black.copy(alpha = 0.75f),
                                                    modifier = Modifier
                                                        .align(Alignment.BottomCenter)
                                                        .fillMaxWidth()
                                                ) {
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(horizontal = 6.dp, vertical = 2.dp),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = if (isSelected) "Активен" else "Выбрать",
                                                            fontSize = 11.sp,
                                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.White
                                                        )
                                                        IconButton(
                                                            onClick = {
                                                                com.example.util.ImageStorageHelper.deleteWallpaperFile(wallpaperPath)
                                                                val updated = settings.withRemovedCustomWallpaper(wallpaperPath)
                                                                onUpdateSettings(updated)
                                                            },
                                                            modifier = Modifier.size(28.dp)
                                                        ) {
                                                            Icon(
                                                                Icons.Default.Delete,
                                                                contentDescription = "Удалить фон",
                                                                tint = Color(0xFFFF6B6B),
                                                                modifier = Modifier.size(16.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        }

                        item {
                            Text("Встроенные пресеты фонов", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Готовые атмосферные иллюстрации и минималистичные темы:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(8.dp))

                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                items(WallpaperPresetsList.filter { !it.isCustom }) { preset ->
                                    val isSelected = settings.chatWallpaperPreset == preset.id
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        border = BorderStroke(2.dp, if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent),
                                        modifier = Modifier
                                            .width(110.dp)
                                            .height(140.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable {
                                                onUpdateSettings(settings.copy(chatWallpaperPreset = preset.id))
                                            }
                                    ) {
                                        Box(modifier = Modifier.fillMaxSize()) {
                                            when {
                                                preset.id == "none" -> {
                                                    Box(
                                                        modifier = Modifier
                                                            .fillMaxSize()
                                                            .background(MaterialTheme.colorScheme.background),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(Icons.Default.Block, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    }
                                                }
                                                else -> {
                                                    com.example.ui.components.ProceduralWallpaper(
                                                        preset = preset.id,
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                }
                                            }

                                            // Label overlay
                                            Surface(
                                                shape = RoundedCornerShape(topStart = 8.dp),
                                                color = Color.Black.copy(alpha = 0.7f),
                                                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Text(
                                                        text = preset.name,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontSize = 10.sp,
                                                        color = Color.White,
                                                        maxLines = 1
                                                    )
                                                }
                                            }

                                            if (isSelected) {
                                                Surface(
                                                    shape = CircleShape,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(20.dp)
                                                ) {
                                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.padding(2.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            // Parallax Switch & Alpha Slider Card
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.ScreenRotation, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Параллакс-эффект", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                            }
                                            Text(
                                                "Фон плавно смещается при наклоне устройства благодаря датчику акселерометра, создавая эффект глубины",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Switch(
                                            checked = settings.parallaxEnabled,
                                            onCheckedChange = { onUpdateSettings(settings.copy(parallaxEnabled = it)) }
                                        )
                                    }
                                    
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.FilterFrames, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Параллакс-эффект рамок", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                            }
                                            Text(
                                                "Рамки аватара смещаются при наклоне устройства",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Switch(
                                            checked = settings.frameParallaxEnabled,
                                            onCheckedChange = { onUpdateSettings(settings.copy(frameParallaxEnabled = it)) }
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Layers, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Хранилище рамок", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                            }
                                            Text(
                                                "Просмотр всех рамок, включая Halloween, и загрузка новых для ботов",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Button(
                                            onClick = { showFrameRepositoryDialog = true },
                                            shape = RoundedCornerShape(10.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text("Открыть", fontSize = 12.sp)
                                        }
                                    }

                                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("Затемнение фона (Прозрачность)", style = MaterialTheme.typography.bodyMedium)
                                            Text("${(settings.chatWallpaperAlpha * 100).toInt()}%", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                        }
                                        Slider(
                                            value = settings.chatWallpaperAlpha,
                                            onValueChange = { onUpdateSettings(settings.copy(chatWallpaperAlpha = it)) },
                                            valueRange = 0.1f..0.85f
                                        )
                                    }
                                }
                            }
                        }

                        item {
                            // Live Interactive Preview Box
                            Text("Живой предпросмотр чата", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Наклоните телефон, чтобы оценить параллакс и контрастность реплик:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(8.dp))

                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
                            ) {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    // Parallax / Video Wallpaper
                                    ParallaxChatWallpaper(
                                        preset = settings.chatWallpaperPreset,
                                        customUri = settings.customWallpaperUri,
                                        alpha = settings.chatWallpaperAlpha,
                                        parallaxEnabled = settings.parallaxEnabled,
                                        liveVideoWallpaperEnabled = settings.liveVideoWallpaperEnabled,
                                        liveVideoWallpaperUri = settings.liveVideoWallpaperUri.ifBlank { settings.customWallpaperUri }
                                    )

                                    // Sample chat messages
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(12.dp),
                                        verticalArrangement = Arrangement.SpaceEvenly
                                    ) {
                                        // Character bubble
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            AppLogo(size = 28.dp, shapeRadius = 14.dp)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp, bottomEnd = 12.dp, bottomStart = 2.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                                            ) {
                                                Text(
                                                    text = "*тихо улыбнулась* Атмосфера здесь действительно особенная...",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                                )
                                            }
                                        }

                                        // User bubble
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp, bottomStart = 12.dp, bottomEnd = 2.dp),
                                                color = Color(settings.accentColorLong).copy(alpha = 0.35f),
                                                border = BorderStroke(1.dp, Color(settings.accentColorLong).copy(alpha = 0.6f))
                                            ) {
                                                Text(
                                                    text = "Да, новые цвета и фон отлично смотрятся!",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Halloween Pumpkin Rain Drop Height Setting with Interactive Preview
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                                ),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            Text("🎃", fontSize = 20.sp)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(
                                                    "Настройки дождя тыковок (Halloween)",
                                                    fontWeight = FontWeight.Bold,
                                                    style = MaterialTheme.typography.bodyMedium
                                                )
                                                Text(
                                                    "Высота падения и прозрачность падающих тыковок на экране",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = MaterialTheme.colorScheme.primaryContainer
                                            ) {
                                                Text(
                                                    "↕ ${(settings.pumpkinRainDropLimit * 100).toInt()}%",
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                    fontSize = 11.sp
                                                )
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = MaterialTheme.colorScheme.secondaryContainer
                                            ) {
                                                Text(
                                                    "👁 ${(settings.pumpkinRainAlpha * 100).toInt()}%",
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                    }

                                    // Interactive Mini Phone Screen Preview
                                    Text(
                                        "Интерактивный предпросмотр падения и прозрачности:",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(180.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(Color.Black.copy(alpha = 0.4f))
                                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
                                    ) {
                                        // Miniature falling pumpkins preview
                                        HalloweenPumpkinRainOverlay(
                                            isActive = true,
                                            onBlackPumpkinTapped = {},
                                            dropLimit = settings.pumpkinRainDropLimit,
                                            pumpkinAlpha = settings.pumpkinRainAlpha,
                                            modifier = Modifier.fillMaxSize()
                                        )

                                        // Cutoff boundary line indicator
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .fillMaxHeight(settings.pumpkinRainDropLimit)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .align(Alignment.BottomCenter)
                                                    .fillMaxWidth()
                                                    .height(2.dp)
                                                    .background(
                                                        Brush.horizontalGradient(
                                                            listOf(
                                                                Color.Transparent,
                                                                MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                                                                MaterialTheme.colorScheme.primary,
                                                                MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                                                                Color.Transparent
                                                            )
                                                        )
                                                    )
                                            )
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier
                                                    .align(Alignment.BottomCenter)
                                                    .offset(y = (-4).dp)
                                            ) {
                                                Text(
                                                    text = "Лимит исчезновения ${(settings.pumpkinRainDropLimit * 100).toInt()}% • Видимость ${(settings.pumpkinRainAlpha * 100).toInt()}%",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onPrimary,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }

                                    // Drop Height Slider
                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("Высота падения тыковок", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                            Text("${(settings.pumpkinRainDropLimit * 100).toInt()}% экрана", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                        }
                                        Slider(
                                            value = settings.pumpkinRainDropLimit,
                                            onValueChange = { onUpdateSettings(settings.copy(pumpkinRainDropLimit = it)) },
                                            valueRange = 0.15f..1.0f
                                        )
                                    }

                                    // Drop Height Presets
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        listOf(
                                            "35% (Верх)" to 0.35f,
                                            "55% (Середина)" to 0.55f,
                                            "70% (Над чатом)" to 0.70f,
                                            "100% (Экран)" to 1.0f
                                        ).forEach { (label, value) ->
                                            val isSelected = kotlin.math.abs(settings.pumpkinRainDropLimit - value) < 0.04f
                                            FilterChip(
                                                selected = isSelected,
                                                onClick = { onUpdateSettings(settings.copy(pumpkinRainDropLimit = value)) },
                                                label = { Text(label, fontSize = 11.sp) }
                                            )
                                        }
                                    }

                                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.18f))

                                    // Pumpkin Opacity Slider
                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("Прозрачность тыковок (Видимость)", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                            Text("${(settings.pumpkinRainAlpha * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                        }
                                        Slider(
                                            value = settings.pumpkinRainAlpha,
                                            onValueChange = { onUpdateSettings(settings.copy(pumpkinRainAlpha = it)) },
                                            valueRange = 0.10f..1.0f
                                        )
                                    }

                                    // Pumpkin Opacity Presets
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        listOf(
                                            "20% (Фон)" to 0.20f,
                                            "45% (Стандарт)" to 0.45f,
                                            "75% (Ярко)" to 0.75f,
                                            "100% (Макс)" to 1.0f
                                        ).forEach { (label, value) ->
                                            val isSelected = kotlin.math.abs(settings.pumpkinRainAlpha - value) < 0.04f
                                            FilterChip(
                                                selected = isSelected,
                                                onClick = { onUpdateSettings(settings.copy(pumpkinRainAlpha = value)) },
                                                label = { Text(label, fontSize = 11.sp) }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                    // AI & Memory Section
                        item {
                            Button(
                                onClick = onOpenProviders,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Cloud, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Настроить AI-провайдеры (OpenRouter / DeepSeek / Gemini)")
                            }
                        }

                        // Gemini Model Safety Threshold Slider (Shown if main provider is Google Gemini)
                        val defaultTextProfile = providers.find { it.isDefaultText }
                        val isGeminiMain = (defaultTextProfile != null && defaultTextProfile.providerType.equals("GEMINI", ignoreCase = true)) ||
                                (providers.find { it.id == settings.defaultTextProviderId }?.providerType.equals("GEMINI", ignoreCase = true)) ||
                                (providers.none { it.isDefaultText } && settings.defaultTextProviderId == null && providers.any { it.providerType.equals("GEMINI", ignoreCase = true) })
                        if (isGeminiMain) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.Security,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(22.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "Порог безопасности Gemini",
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                            ) {
                                                Text(
                                                    text = "PROHIBITED_CONTENT FIX",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 9.sp,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "Управляет фильтрацией safetySettings API (Harassment, Hate Speech, Sexually Explicit, Dangerous Content). Установите 'Отключено (BLOCK_NONE)', чтобы исключить пустые ответы из-за блокировки PROHIBITED_CONTENT.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )

                                        Spacer(modifier = Modifier.height(14.dp))

                                        val safetyLevels = listOf(
                                            "BLOCK_NONE" to ("Отключено (BLOCK_NONE)" to "Полная свобода ролплея, блокировки сняты"),
                                            "BLOCK_ONLY_HIGH" to ("Минимальный (BLOCK_ONLY_HIGH)" to "Блокировать только экстремальный риск"),
                                            "BLOCK_MEDIUM_AND_ABOVE" to ("Стандартный (BLOCK_MEDIUM_AND_ABOVE)" to "Блокировать средний и высокий риск"),
                                            "BLOCK_LOW_AND_ABOVE" to ("Строгий (BLOCK_LOW_AND_ABOVE)" to "Блокировать большинство спорных тем")
                                        )
                                        val currentIdx = safetyLevels.indexOfFirst { it.first == settings.geminiSafetyThreshold }.coerceAtLeast(0)

                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.75f),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Text(
                                                    text = safetyLevels[currentIdx].second.first,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    style = MaterialTheme.typography.bodyMedium
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = safetyLevels[currentIdx].second.second,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))

                                        Slider(
                                            value = currentIdx.toFloat(),
                                            onValueChange = { newVal ->
                                                val newIdx = kotlin.math.round(newVal).toInt().coerceIn(0, 3)
                                                val newThreshold = safetyLevels[newIdx].first
                                                if (newThreshold != settings.geminiSafetyThreshold) {
                                                    onUpdateSettings(settings.copy(geminiSafetyThreshold = newThreshold))
                                                }
                                            },
                                            valueRange = 0f..3f,
                                            steps = 2,
                                            modifier = Modifier.fillMaxWidth()
                                        )

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("Отключено", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                            Text("Минимум", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text("Стандарт", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text("Строгий", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }

                        // Custom Global System Prompt
                        item {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                                modifier = Modifier
                                    .studioElement("settings_generation_card")
                                    .fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Column(modifier = Modifier.fillMaxWidth()) {
                                        Text(
                                            "Пользовательский системный промпт",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            "Дополнительные общие директивы для всех ботов (или замена системного стиля)",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Small download button proposing to download the system prompt with warning
                                        FilledTonalButton(
                                            onClick = { showDownloadPromptConfirmDialog = true },
                                            enabled = !isDownloadingPrompt,
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            if (isDownloadingPrompt) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(14.dp),
                                                    strokeWidth = 2.dp,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            } else {
                                                Icon(
                                                    Icons.Default.CloudDownload,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(15.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Скачать", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                            }
                                        }

                                        if (settings.customSystemPrompt.isNotBlank()) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            TextButton(
                                                onClick = {
                                                    onUpdateSettings(
                                                        settings.copy(
                                                            customSystemPrompt = "",
                                                            systemPromptVersion = "",
                                                            downloadedSystemPrompt = "",
                                                            isSystemPromptUserModified = false
                                                        )
                                                    )
                                                },
                                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                                modifier = Modifier.height(32.dp)
                                            ) {
                                                Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(15.dp))
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text("Сбросить", fontSize = 11.sp)
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    // Display version above system prompt ONLY if not modified by user
                                    if (settings.isSystemPromptUnmodified && settings.systemPromptVersion.isNotBlank()) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)),
                                            modifier = Modifier.padding(bottom = 6.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Verified,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "Версия системного промпта: ${settings.systemPromptVersion}",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                                )
                                            }
                                        }
                                    }

                                    var customPromptInput by remember(settings.customSystemPrompt) {
                                        mutableStateOf(settings.customSystemPrompt)
                                    }

                                    OutlinedTextField(
                                        value = customPromptInput,
                                        onValueChange = { newValue ->
                                            customPromptInput = newValue
                                            val isModified = settings.downloadedSystemPrompt.isNotBlank() &&
                                                newValue.trim() != settings.downloadedSystemPrompt.trim()
                                            onUpdateSettings(
                                                settings.copy(
                                                    customSystemPrompt = newValue,
                                                    isSystemPromptUserModified = isModified
                                                )
                                            )
                                        },
                                        placeholder = {
                                            Text("Оставьте пустым для использования стандартного качественного промпта движка...")
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(min = 100.dp, max = 220.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                        )
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    OutlinedButton(
                                        onClick = { showDefaultPromptDialog = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(Icons.Default.Terminal, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Просмотреть стандартный системный промпт")
                                    }

                                    if (settings.customSystemPrompt.isBlank()) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            "Используется стандартный системный промпт движка с поддержкой естественных мыслей, диалогов и эмоционального погружения.",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }

                        item {
                            Text("Длина системного контекста (Сообщений)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Сколько последних реплик передаётся модели в промпте: ${settings.contextWindowSize}", style = MaterialTheme.typography.bodyMedium)
                            Slider(
                                value = settings.contextWindowSize.toFloat(),
                                onValueChange = { onUpdateSettings(settings.copy(contextWindowSize = it.toInt())) },
                                valueRange = 4f..30f,
                                steps = 25
                            )
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Лимит карточки персонажа", fontWeight = FontWeight.Bold)
                                    Text("Режим расширенного описания бота (до 50000 символов)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = settings.characterLimitMode == "extended",
                                    onCheckedChange = {
                                        onUpdateSettings(settings.copy(characterLimitMode = if (it) "extended" else "standard"))
                                    }
                                )
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Отладка внутреннего рассуждения", fontWeight = FontWeight.Bold)
                                    Text("Отображать теги скрытых мыслей <thought> под репликами", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = settings.showInternalReasoningDebug,
                                    onCheckedChange = { onUpdateSettings(settings.copy(showInternalReasoningDebug = it)) }
                                )
                            }
                        }

                        item {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.BugReport,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("Режим отладки Gemini (Gemini Debug)", fontWeight = FontWeight.Bold)
                                            }
                                            Text(
                                                "Детальное логирование жизненного цикла запросов к Gemini API, streaming chunks и кодов ответа",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Switch(
                                            checked = settings.geminiDebugEnabled,
                                            onCheckedChange = {
                                                com.example.ai.debug.GeminiDebugLogger.isDebugModeGloballyEnabled = it
                                                onUpdateSettings(settings.copy(geminiDebugEnabled = it))
                                            }
                                        )
                                    }

                                    OutlinedButton(
                                        onClick = onOpenGeminiDebug,
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Экран диагностики Gemini (Test & Chunks)")
                                    }
                                }
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Голосовые сообщения", fontWeight = FontWeight.Bold)
                                    Text("Запись и отправка голосовых сообщений с распознаванием речи в диалогах", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = settings.voiceMessagesEnabled,
                                    onCheckedChange = { onUpdateSettings(settings.copy(voiceMessagesEnabled = it)) }
                                )
                            }
                        }

                    // 4. Поведение и длина ответов (Behavior & Tokens)
                        item {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.Tune,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    "Глобальный лимит токенов на ответ ИИ",
                                                    fontWeight = FontWeight.Bold,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                "Единая настройка для всех чатов, персонажей и моделей: ${settings.defaultMaxTokens} токенов (~${(settings.defaultMaxTokens * 0.75).toInt()} слов)",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Slider(
                                        value = settings.defaultMaxTokens.toFloat().coerceIn(100f, 8192f),
                                        onValueChange = { onUpdateSettings(settings.copy(defaultMaxTokens = it.toInt())) },
                                        valueRange = 100f..8192f,
                                        steps = 80
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = "Быстрый выбор пресетов:",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))

                                    LazyRow(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        items(listOf(250, 500, 1000, 1500, 2048, 4096, 8192)) { preset ->
                                            FilterChip(
                                                selected = settings.defaultMaxTokens == preset,
                                                onClick = { onUpdateSettings(settings.copy(defaultMaxTokens = preset)) },
                                                label = { Text("$preset", fontSize = 11.sp) },
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.AutoAwesome,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "При низком лимите токенов модель генерирует короткие, ёмкие посты с обязательным логическим завершением всех фраз и предложений, без обрыва текста на середине.",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            "Режим появления текста бота",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Выбор между эффектом печати символов и мгновенным выводом ответа",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        FilterChip(
                                            selected = settings.botTextAppearanceMode == "typing",
                                            onClick = { onUpdateSettings(settings.copy(botTextAppearanceMode = "typing")) },
                                            label = { Text("⌨️ Печатание", fontSize = 12.sp) },
                                            modifier = Modifier.weight(1f)
                                        )
                                        FilterChip(
                                            selected = settings.botTextAppearanceMode == "instant",
                                            onClick = { onUpdateSettings(settings.copy(botTextAppearanceMode = "instant")) },
                                            label = { Text("⚡ Мгновенно", fontSize = 12.sp) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }

                                    if (settings.botTextAppearanceMode == "typing") {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = "Скорость печатания: ${settings.botTypingSpeedMs} мс/символ",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Slider(
                                            value = settings.botTypingSpeedMs.toFloat().coerceIn(1f, 100f),
                                            onValueChange = { onUpdateSettings(settings.copy(botTypingSpeedMs = it.toInt())) },
                                            valueRange = 1f..100f,
                                            steps = 20
                                        )
                                        LazyRow(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            items(listOf(5 to "Быстро (5мс)", 15 to "Стандарт (15мс)", 30 to "Медленно (30мс)", 60 to "Плавно (60мс)")) { (preset, label) ->
                                                FilterChip(
                                                    selected = settings.botTypingSpeedMs == preset,
                                                    onClick = { onUpdateSettings(settings.copy(botTypingSpeedMs = preset)) },
                                                    label = { Text(label, fontSize = 11.sp) }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FastForward,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text("Продолжение по кнопке «Отправить»", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                        Text("Если поле ввода пустое, нажатие на кнопку ⏩ отправляет невидимую команду боту продолжать свою мысль или историю.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Генерация в фоне и служба", fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = MaterialTheme.colorScheme.tertiaryContainer
                                        ) {
                                            Text("ФОН", fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp), color = MaterialTheme.colorScheme.tertiary)
                                        }
                                    }
                                    Text("Продолжать генерацию при свёрнутом приложении или выключенном экране с присылкой уведомления о готовности", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = settings.backgroundNotificationsEnabled,
                                    onCheckedChange = { onUpdateSettings(settings.copy(backgroundNotificationsEnabled = it)) }
                                )
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Глобальный NSFW 18+", fontWeight = FontWeight.Bold)
                                    Text("Автоматически включать 18+ для взрослых персонажей", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = settings.globalDefaultNsfw,
                                    onCheckedChange = { onUpdateSettings(settings.copy(globalDefaultNsfw = it)) }
                                )
                            }
                        }

                        item {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                                modifier = Modifier
                                    .studioElement("settings_tts_card")
                                    .fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Mic,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Голосовые сообщения", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            "Запись голосовых реплик с распознаванием речи. Бот получает распознанный текст, а вам доступен плеер записи в чате",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Switch(
                                        checked = settings.voiceMessagesEnabled,
                                        onCheckedChange = { onUpdateSettings(settings.copy(voiceMessagesEnabled = it)) }
                                    )
                                }
                            }
                        }

                    // 5. О приложении & Резервные копии (System)
                        item {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    AppLogo(size = 64.dp, shapeRadius = 32.dp)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text("Untitled", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                    Text("Версия 1.0-alpha • Свободный ролевой движок", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                    
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "Мощный, независимый ролплей-движок для общения с любимыми персонажами. Без цензуры, без жестких лимитов, с поддержкой открытых ИИ-провайдеров и локальной конфиденциальностью данных.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        // Remote Update Status & Config Card
                        item {
                            var isCheckingUpdate by remember { mutableStateOf(false) }
                            var updateResultText by remember { mutableStateOf<String?>("Версия ${com.example.util.RemoteUpdateChecker.CURRENT_APP_VERSION} (Актуальная)") }
                            var isNewerAvailable by remember { mutableStateOf(false) }
                            val coroutineScope = rememberCoroutineScope()

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(
                                                Icons.Default.CloudSync,
                                                contentDescription = null,
                                                tint = if (isNewerAvailable) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(
                                                    text = "Дистанционные обновления",
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = updateResultText ?: "Версия ${com.example.util.RemoteUpdateChecker.CURRENT_APP_VERSION}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = if (isNewerAvailable) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }

                                        FilledTonalButton(
                                            onClick = {
                                                isCheckingUpdate = true
                                                coroutineScope.launch {
                                                    val result = com.example.util.RemoteUpdateChecker.checkForUpdates()
                                                    isCheckingUpdate = false
                                                    if (result.isSuccess) {
                                                        val manifest = result.getOrNull()
                                                        if (manifest?.hasUpdate == true) {
                                                            isNewerAvailable = true
                                                            updateResultText = "🚀 Есть новая версия: v${manifest.latestVersion}!"
                                                        } else {
                                                            isNewerAvailable = false
                                                            updateResultText = "✅ Актуальная версия v${com.example.util.RemoteUpdateChecker.CURRENT_APP_VERSION}"
                                                        }
                                                    } else {
                                                        isNewerAvailable = false
                                                        updateResultText = "ℹ️ Актуальная версия v${com.example.util.RemoteUpdateChecker.CURRENT_APP_VERSION} (Сервер не ответил)"
                                                    }
                                                }
                                            },
                                            enabled = !isCheckingUpdate,
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            if (isCheckingUpdate) {
                                                CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                                            } else {
                                                Text("Проверить", fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Button(
                                onClick = onOpenBackup,
                                modifier = Modifier
                                    .studioElement("settings_backup_card")
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Backup, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Резервные копии и экспорт ZIP")
                            }
                        }

                        // Telegram Channel Card
                        item {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable {
                                        try {
                                            val intent = android.content.Intent(
                                                android.content.Intent.ACTION_VIEW,
                                                Uri.parse("https://t.me/UntitledAI")
                                            )
                                            context.startActivity(intent)
                                        } catch (_: Exception) {
                                            // fallback
                                        }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = Color(0xFF229ED9),
                                        modifier = Modifier.size(44.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.Send,
                                                contentDescription = "Telegram",
                                                tint = Color.White,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(14.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Telegram-канал движка",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "@UntitledAI • Новости, обновления и поддержка",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Icon(
                                         imageVector = Icons.Default.OpenInNew,
                                         contentDescription = "Открыть",
                                         tint = MaterialTheme.colorScheme.primary,
                                         modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        // Features List
                        item {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("Особенности приложения:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    
                                    val features = listOf(
                                        "⚡ Открытый доступ к OpenRouter, Polza.ai, Groq и любым совместимым эндпоинтам",
                                        "🔞 Полная поддержка 18+ ролплея и отсутствие ограничений тем",
                                        "🎭 Персоны пользователя: выбирайте от чьего лица ведете диалог",
                                        "🧠 Автономный встроенный Untitled Ассистент для помощи и отладки",
                                        "🔀 Ветвление диалогов и возможность альтернативных сюжетов",
                                        "🖼️ Кастомизация фонов, параллакс-эффект и цветовая палитра",
                                        "📦 Полное резервное копирование и экспорт персонажей в JSON"
                                    )

                                    features.forEach { feat ->
                                        Text(
                                            text = feat,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }

                if (showFrameRepositoryDialog) {
                    UserFrameRepositoryDialog(
                        userAvatarUri = "",
                        currentSelectedFrameUri = settings.userActiveFrameUri,
                        rawFramesJson = settings.userFramesJson,
                        onDismiss = { showFrameRepositoryDialog = false },
                        onSelectFrame = { selectedUri ->
                            onUpdateSettings(settings.copy(userActiveFrameUri = selectedUri))
                            showFrameRepositoryDialog = false
                        },
                        onSaveFramesJson = { updatedJson ->
                            onUpdateSettings(settings.copy(userFramesJson = updatedJson))
                        }
                    )
                }
            }
        }
    }
