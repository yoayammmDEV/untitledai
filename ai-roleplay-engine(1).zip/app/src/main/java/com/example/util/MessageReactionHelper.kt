package com.example.util

data class MessageReaction(
    val emoji: String,
    val titleRu: String,
    val descriptionRu: String,
    val signalRu: String,
    val isPositive: Boolean
)

object MessageReactionHelper {

    val POSITIVE_REACTIONS = listOf(
        MessageReaction(
            emoji = "❤️",
            titleRu = "В восторге",
            descriptionRu = "Отличный ход сюжета",
            signalRu = "Пользователю невероятно понравился этот поворот сюжета, эмоции и стиль отыгрыша. Продолжай развивать эту тему и атмосферу в том же ключе!",
            isPositive = true
        ),
        MessageReaction(
            emoji = "🔥",
            titleRu = "Страстно",
            descriptionRu = "Яркие эмоции и накал",
            signalRu = "Пользователь оценил высокий накал страстей, чувственность и динамику момента. Поддерживай эту близость, чувственность и живой драйв.",
            isPositive = true
        ),
        MessageReaction(
            emoji = "👍",
            titleRu = "Одобряю",
            descriptionRu = "Хорошее направление",
            signalRu = "Пользователь одобряет выбранное действие и реакцию персонажа. Двигайся дальше по этой ветке событий.",
            isPositive = true
        ),
        MessageReaction(
            emoji = "🎯",
            titleRu = "В характере",
            descriptionRu = "Идеальное попадание в образ",
            signalRu = "Пользователь отмечает точное попадание в каноничный характер, привычки и психологию персонажа. Сохраняй именно эту манеру речи и мышления!",
            isPositive = true
        ),
        MessageReaction(
            emoji = "✨",
            titleRu = "Интригует",
            descriptionRu = "Интересный сюжетный крючок",
            signalRu = "Пользователя заинтриговала эта деталь или сюжетный ход. Разверни эту интригу глубже и добавь неожиданных подробностей.",
            isPositive = true
        )
    )

    val NEGATIVE_REACTIONS = listOf(
        MessageReaction(
            emoji = "👎",
            titleRu = "Не то",
            descriptionRu = "Неудачное направление",
            signalRu = "Пользователю не понравилось данное действие или развитие событий. Плавно скорректируй вектор сюжета и предложи более удачный ход.",
            isPositive = false
        ),
        MessageReaction(
            emoji = "🛑",
            titleRu = "Не в характере (OOC)",
            descriptionRu = "Нарушение канона / фальшиво",
            signalRu = "Персонаж повел себя не в своем характере (Out of Character) или неестественно. Срочно вернись к изначальному психотипу, тону и поведению из описания карточки!",
            isPositive = false
        ),
        MessageReaction(
            emoji = "⚠️",
            titleRu = "Слишком быстро",
            descriptionRu = "Спешка / нелогичный темп",
            signalRu = "События или сближение развиваются слишком торопливо или скомкано. Замедли темп (pacing), удели внимание окружению, мелким жестам, паузам и внутренним мыслям.",
            isPositive = false
        ),
        MessageReaction(
            emoji = "💔",
            titleRu = "Сухо / Пресно",
            descriptionRu = "Не хватает эмоций",
            signalRu = "Ответ показался пользователю пресным или пассивным. Добавь больше выразительных эмоций, телесных реакций, инициативы и активных действий персонажа.",
            isPositive = false
        )
    )

    val ALL_REACTIONS: List<MessageReaction> = POSITIVE_REACTIONS + NEGATIVE_REACTIONS

    fun getReactionInfo(emoji: String?): MessageReaction? {
        if (emoji.isNullOrBlank()) return null
        return ALL_REACTIONS.find { it.emoji == emoji }
    }

    fun getReactionSignal(emoji: String?): String? {
        if (emoji.isNullOrBlank()) return null
        return ALL_REACTIONS.find { it.emoji == emoji }?.signalRu
    }
}
