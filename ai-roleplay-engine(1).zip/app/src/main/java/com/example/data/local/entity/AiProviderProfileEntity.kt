package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ai_provider_profiles")
data class AiProviderProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val providerType: String, // "OPENROUTER", "OPENAI", "ANTHROPIC", "GEMINI", "CUSTOM"
    val baseUrl: String = "",
    val apiKey: String = "",
    val model: String = "deepseek/deepseek-chat",
    val temperature: Float = 0.85f,
    val topP: Float = 0.95f,
    val maxTokens: Int = 1500,
    val systemPromptTemplate: String = "",
    val isDefaultText: Boolean = false,
    val isDefaultImage: Boolean = false,
    val isImageProvider: Boolean = false,
    val negativePrompt: String = "ugly, deformed, disfigured, low quality, blurry, nsfw if disabled",
    val imageResolution: String = "1024x1024",
    val seedMode: String = "random", // "random", "fixed"
    val fixedSeed: Long = 42L,
    val visionModel: String = "google/gemma-4-26b-a4b-it:free" // Vision model for multimodal image understanding
)
