package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "characters")
data class CharacterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val avatarUri: String,
    val shortDescription: String = "",
    val personality: String = "",
    val appearance: String = "",
    val referenceImages: String = "[]", // JSON array of URIs / paths
    val habits: String = "",
    val likes: String = "",
    val dislikes: String = "",
    val greetingMessage: String = "",
    val age: Int = 18,
    val birthDate: String = "",
    val knowledgeCards: String = "[]", // JSON array of {title, content}
    val tags: String = "[]", // JSON array of strings
    val voiceStyle: String = "natural", // formal, cheeky, shy, dramatic, gentle, cold, playful
    val isAdult: Boolean = true, // age >= 18 hardware-enforced
    val startingRelationship: String = "strangers", // strangers, acquaintances, friends, close_friends, romantic, custom
    val customRelationship: String = "",
    val bannerUri: String = "", // Картинка-баннер для шапки персонажа в профиле и хранилище
    val communicationFormality: String = "adaptive", // adaptive, informal_ty, formal_vy, distant, flirty, submissive, dominant
    val avatarFrameUri: String = "", // Картинка рамки с прозрачным фоном для аватарки
    val greetingBannerUri: String = "", // Картинка-баннер для приветственного поста / сообщения
    val isPinned: Boolean = false,
    val isArchived: Boolean = false,
    val isHidden: Boolean = false,
    val lastInteractedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val author: String = "UntitledAI"
) {
    val by: String get() = author

    val isAssistant: Boolean
        get() = tags.contains("assistant", ignoreCase = true) ||
                tags.contains("Ассистент", ignoreCase = true) ||
                tags.contains("Помощь", ignoreCase = true) ||
                name.equals("PersonaAI Ассистент", ignoreCase = true) ||
                name.equals("PersonaAI Assistant", ignoreCase = true) ||
                name.equals("Untitled Ассистент", ignoreCase = true) ||
                name.contains("Ассистент", ignoreCase = true) ||
                name.contains("Assistant", ignoreCase = true)

    fun getDisplayName(isEn: Boolean = false): String {
        if (isAssistant) {
            return if (isEn) "Untitled Assistant" else "Untitled Ассистент"
        }
        return name
    }

    fun getDisplayDescription(isEn: Boolean = false): String {
        if (isAssistant) {
            return if (isEn) {
                "Official Untitled built-in AI assistant and technical advisor. Helps configure models, solve errors, and refine roleplay prompts."
            } else {
                "Официальный ИИ-помощник движка Untitled. Подскажет настройки, исправит ошибки, поможет с промптами."
            }
        }
        return shortDescription
    }

    fun getDisplayGreeting(isEn: Boolean = false): String {
        if (isAssistant && isEn) {
            return "Greetings! I am the Untitled Assistant, your built-in advisor for Untitled.\n\nI will help you configure AI providers, choose optimal model parameters, create character or user persona cards, and guide you through resolving any errors.\n\nFeel free to ask any questions about the app or settings!"
        }
        return greetingMessage
    }
}
